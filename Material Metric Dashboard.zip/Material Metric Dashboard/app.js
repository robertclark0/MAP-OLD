var myApp = angular.module('myApp', ['ngMaterial']);

myApp.config(function ($mdThemingProvider) {
    $mdThemingProvider.theme('default')
      .primaryPalette('green')
      .accentPalette('blue');
});

myApp.controller('MainController', ['$scope', '$mdSidenav', function ($scope, $mdSidenav) {

    $scope.test = 'Angular is working';



    $scope.showConfirm = function (ev) {
        // Appending dialog to document.body to cover sidenav in docs app
        var confirm = $mdDialog.confirm()
			  .title('Would you like to delete your debt?')
			  .textContent('All of the banks have agreed to forgive you your debts.')
			  .ariaLabel('Lucky day')
			  .targetEvent(ev)
			  .ok('Please do it!')
			  .cancel('Sounds like a scam');
        $mdDialog.show(confirm).then(function () {
            alert('You decided to get rid of your debt.');
        }, function () {
            alert('You decided to keep your debt.');
        });
    };

    $scope.rightLock = false;
    $scope.lockRight = function () {
        $scope.rightLock = !$scope.rightLock;
    }
    $scope.toggleRight = function () {
        console.log('trying to open ');

        $mdSidenav('right').toggle();



    };


}]);