var myApp = angular.module('myApp', ['ngMaterial', 'gridster']);

myApp.config(function ($mdThemingProvider) {
    $mdThemingProvider.theme('default')
      .primaryPalette('green')
      .accentPalette('blue');
});

myApp.controller('MainController', ['$scope', '$mdSidenav', function ($scope, $mdSidenav) {

    $scope.test = 'Angular is working';

    $scope.list = ['Data Group 1', 'Data Group 2', 'Data Group 3'];

    $scope.showConfirm = function (ev) {
        // Appending dialog to document.body to cover sidenav in docs app
        var confirm = $mdDialog.confirm()
			  .title('Would you like to delete your debt?')
			  .textContent('All of the banks have agreed to forgive you your debts.')
			  .ariaLabel('Lucky day')
			  .targetEvent(ev)
			  .ok('Please do it!')
			  .cancel('Sounds like a scam');
        $mdDialog.show(confirm).then(function () {
            alert('You decided to get rid of your debt.');
        }, function () {
            alert('You decided to keep your debt.');
        });
    };

    $scope.rightLock = false;
    $scope.lockRight = function () {
        $scope.rightLock = !$scope.rightLock;
    }
    $scope.toggleRight = function () {
        console.log('trying to open ');

        $mdSidenav('right').toggle();



    };

    $scope.standardItems = [
      { sizeX: 2, sizeY: 1, row: 0, col: 0 },
      { sizeX: 2, sizeY: 2, row: 0, col: 2 },
      { sizeX: 1, sizeY: 1, row: 0, col: 4 },
      { sizeX: 1, sizeY: 1, row: 0, col: 5 },
      { sizeX: 2, sizeY: 1, row: 1, col: 0 },
      { sizeX: 1, sizeY: 1, row: 1, col: 4 },
      { sizeX: 1, sizeY: 2, row: 1, col: 5 },
      { sizeX: 1, sizeY: 1, row: 2, col: 0 },
      { sizeX: 2, sizeY: 1, row: 2, col: 1 },
      { sizeX: 1, sizeY: 1, row: 2, col: 3 },
      { sizeX: 1, sizeY: 1, row: 2, col: 4 }
    ];
    $scope.gridsterOpts = {
        columns: 36
    };


}]);