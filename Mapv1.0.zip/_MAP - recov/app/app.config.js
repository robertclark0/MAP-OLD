﻿mapApp.config(function ($stateProvider, $urlRouterProvider) {
    
    $urlRouterProvider.otherwise("/platform-home/product-lines");

    $stateProvider
        .state("platformHome", {
            url: "/platform-home",
            templateUrl: "core-components/platform-home/view.html",
            css: { href: "core-components/platform-home/style.css" },
            controller: "PlatformHome"
        })
        .state("platformHome.productLines", {
            url: "/product-lines",
            templateUrl: "core-components/platform-home/templates/product-lines.html",
            css: { href: "core-components/platform-home/style.css" },
            controller: "PlatformHome"
        })
        .state("platformHome.about", {
            url: "/about",
            templateUrl: "core-components/platform-home/templates/about.html",
            css: { href: "core-components/platform-home/style.css" }
        })
        .state("metricDashboardReporting", {
            url: "/metric-dashboard/reporting",
            css: { href: "core-components/metric-dashboard/style.css" },
            views: {
                "": {
                    templateUrl: "core-components/metric-dashboard/view.html",
                    controller: 'MetricDashboard',
                },
                "left@metricDashboardReporting": {
                    templateUrl: "core-components/metric-dashboard/templates/report-left.html",
                    controller: "MetricDashboardReportLeft"
                },
                "canvas@metricDashboardReporting": {
                    templateUrl: "core-components/metric-dashboard/templates/report.html",
                    controller: "MetricDashboardCanvas"
                },
                "right@metricDashboardReporting": {
                    template: "<div></div>",
                }
            }
        })
        .state("metricDashboard", {
            url: "/metric-dashboard",
            css: { href: "core-components/metric-dashboard/style.css" },
            views: {
                "": {
                    templateUrl: "core-components/metric-dashboard/view.html",
                    controller: 'MetricDashboard',
                },
                "left@metricDashboard": {
                    templateUrl: "core-components/metric-dashboard/templates/left.html",
                    controller: "MetricDashboardLeft",
                },
                "canvas@metricDashboard": {
                    templateUrl: "core-components/metric-dashboard/templates/canvas.html",
                    controller: "MetricDashboardCanvas"
                },
                "right@metricDashboard": {
                    templateUrl: "core-components/metric-dashboard/templates/right.html",
                    controller: "MetricDashboardRight"
                }
            }
        })
        .state("metricDashboard.grid", {
            css: { href: "core-components/metric-dashboard/style.css" },
            views: {
                "canvas@metricDashboard": {
                    templateUrl: "core-components/metric-dashboard/templates/grid.html",
                    controller: "MetricDashboardCanvas"
                }
            }
        })
        .state("metricDashboard.canvas", {
            css: { href: "core-components/metric-dashboard/style.css" },
            views: {
                "canvas@metricDashboard": {
                    templateUrl: "core-components/metric-dashboard/templates/canvas.html",
                    controller: "MetricDashboardCanvas"
                }
            }
        });

});