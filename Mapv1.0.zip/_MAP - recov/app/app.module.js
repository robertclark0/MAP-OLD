﻿var mapApp = angular.module('mapApp', [
    'ui.router',
    'door3.css',
    'slick',
    'jQueryScrollbar',
    'platformHome',
    'metricDashboard',
    'gridster',
    'ngStorage',
    'ui.bootstrap'
]);