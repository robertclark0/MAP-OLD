﻿mapApp.controller('MainController', ['$scope', function ($scope) {

    $scope.testValue01 = "AngularJS is Working";
    $scope.testValue02 = "AngularJS is Still Working";


}]);