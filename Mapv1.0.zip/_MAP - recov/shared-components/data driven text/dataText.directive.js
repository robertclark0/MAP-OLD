﻿mapApp.directive('dataText', function () {

    return {
        templateUrl: 'shared-components/textBlock/textBlock.html',
        link: link,
        scope: {
            element: "="
        }
    };

    function link(scope) {

        var template = [
            { name: 'title', type: 'string', value: 'Title' },
            { name: 'Show Title', type: 'bool', value: true },
            { name: 'text', type: 'multiline', value: 'Text Area' },
        ];

        scope.element.properties = scope.element.properties || angular.copy(template);

    };
});