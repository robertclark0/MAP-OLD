﻿mapApp.directive('listControll', function () {

    return {
        restrict: 'EA',
        replace: true,
        templateUrl: 'shared-components/list-controll/list-controll.html',
        scope: {
            list: "=",
            out: "=",
            selectable: "=",
            callFunction: "&"
        },
        link: link
    }

    function link(scope, elem) {

        scope.$watch('list', function (newVal) {
            if (newVal) {
                scope.key = Object.keys(scope.list[0])[0];
            }            
        }, true);

        scope.isSelected = function (key, value) {
            
            var selectedValues = scope.out.map(function (obj) {
                return obj[key];
            })

            if (selectedValues.indexOf(value) > -1) {
                return true;
            }
            return false;
        };

    }

});
//list-controll directive