﻿metricDashboard.factory('dataManager', function ($resource, $rootScope, $http) {

    var dataScope = $rootScope.$new(true);
    var apiEndPoint = 'http://localhost:49460/api';
    //var apiEndPoint = 'https://pasbadevweb/MAP/api';

    //    DATA OBJECT
    //
    var dataObject = {};

    dataObject.queryValues = {
        table: "Telehealth_360_CAPER",
    }

    //    DATA RESOURCES
    //
    var dataResource = {};

    dataResource.findDataObject = function (DOArray, canvasIndex, groupIndex) {

        var index = -1;
        for (var i = 0; i < DOArray.length; i++) {
            var element = DOArray[i];
            if (element.canvas === canvasIndex && element.dataGroup === groupIndex) { index = i; break; }
        }
        return index;
    };
    dataResource.updateArray = function (sourceArray, targetArray, group) {
        targetArray.length = 0;
        sourceArray.forEach(function (entry) {
            entry = dataResource.checkCalculation(entry, group);
            targetArray.push(entry);
        });
    }
    dataResource.checkCalculation = function (entryObject, group) {
        var calc = group.data.calc;

        if (calc && calc.column1 && entryObject[calc.column1] && calc.column2 && entryObject[calc.column2]) {

            switch (calc.operator) {

                case "+":
                    entryObject[calc.as] = (parseFloat(entryObject[calc.column1] || 0) + parseFloat(entryObject[calc.column2] || 0)).toFixed(2);
                    break;

                case "-":
                    entryObject[calc.as] = (parseFloat(entryObject[calc.column1] || 0) - parseFloat(entryObject[calc.column2] || 0)).toFixed(2);
                    break;

                case "*":
                    entryObject[calc.as] = (parseFloat(entryObject[calc.column1] || 0) * parseFloat(entryObject[calc.column2] || 0)).toFixed(2);
                    break;

                case "/":
                    entryObject[calc.as] = (parseFloat(entryObject[calc.column1] || 0) / parseFloat(entryObject[calc.column2] || 0)).toFixed(2);
                    break;
            }
        }

        return entryObject;
    };

    dataResource.exportToCsv = function(filename, rows) {
        var processRow = function (row) {
            var finalVal = '';
            for (var j = 0; j < row.length; j++) {
                var innerValue = row[j] === null ? '' : row[j].toString();
                if (row[j] instanceof Date) {
                    innerValue = row[j].toLocaleString();
                };
                var result = innerValue.replace(/"/g, '""');
                if (result.search(/("|,|\n)/g) >= 0)
                    result = '"' + result + '"';
                if (j > 0)
                    finalVal += ',';
                finalVal += result;
            }
            return finalVal + '\n';
        };
        var processJSON = function (row) {
            var finalVal = '';
            var keys = Object.keys(row);

            for (var j = 0; j < keys.length; j++) {
                var innerValue = row[keys[j]] === null ? '' : row[keys[j]].toString();
                var result = innerValue.replace(/"/g, '""');
                if (result.search(/("|,|\n)/g) >= 0)
                    result = '"' + result + '"';
                if (j > 0)
                    finalVal += ',';
                finalVal += result;
            }
            return finalVal + '\n';
        }
        var csvFile = '';
        //header
        var headerKeys = Object.keys(rows[0]);
        csvFile += headerKeys.join(",") + '\n';

        for (var i = 0; i < rows.length; i++) {
            //csvFile += processRow(rows[i]);
            csvFile += processJSON(rows[i]);
        }

        var blob = new Blob([csvFile], { type: 'text/csv;charset=utf-8;' });
        if (navigator.msSaveBlob) { // IE 10+
            navigator.msSaveBlob(blob, filename);
        } else {
            var link = document.createElement("a");
            if (link.download !== undefined) { // feature detection
                // Browsers that support HTML5 download attribute
                var url = URL.createObjectURL(blob);
                link.setAttribute("href", url);
                link.setAttribute("download", filename);
                link.style.visibility = 'hidden';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            }
        }
    }

    var userInfoAPI = apiEndPoint + '/appInfo/';
    dataResource.userInfo = function () { return $resource(userInfoAPI); };

    var tableColumnDataAPI = apiEndPoint + '/table/';
    dataResource.tableColumnData = $resource(tableColumnDataAPI + '?table=' + dataObject.queryValues.table);

    var distinctColumnDataAPI = apiEndPoint + '/column/';
    dataResource.testDistinctColumnData = function (columnName, columnType) {
        return $resource(distinctColumnDataAPI + '?table=' + dataObject.queryValues.table + '&colName=' + columnName + '&colType=' + columnType);
    }

    var queryAPI = apiEndPoint + '/query/';
    dataResource.queryData = function (queryObject) {
        var queryString = createQueryString(queryObject);
        return $resource(queryAPI + queryString);
    }

    var reportAPI = apiEndPoint + '/report/';
    dataResource.reports = function (reportObject) {
        var report = createReportPost(reportObject);
        return $http.post(reportAPI, JSON.stringify(report));
    }
    dataResource.getReports = function (type) {
        var queryString = "?reportType=" + type;
        return $resource(reportAPI + queryString);
    };

    var updateReportApi = apiEndPoint + '/update-report/?update=1';
    dataResource.updateReport = function (reportObject) {
        var report = createReportPost(reportObject);
        return $http.post(updateReportApi, JSON.stringify(report));
    }

    var deleteReportAPI = apiEndPoint + '/delete-report/';
    dataResource.deleteReport = function (GUID) {
        return $resource(deleteReportAPI + '?GUID=' + GUID + '&delete=1')
    }
    

    //  DOOOO IT! GET THAT DATAAAA!
    var createQueryString = function (queryObject) {

        var table = "?table=" + queryObject.table;

        var column = "";
        if (queryObject.column.length > 0) {
            column  = "&column=" + queryObject.column.join(",")
        }

        var aggType = "";
        if (queryObject.aggTypes.length > 0) {
            aggType = "&aggType=" + queryObject.aggTypes.join(",")
        }
        
        var group = "";
        if (queryObject.group.length > 0) {
            group = "&group=" + queryObject.group.join(",")
        }

        var partition = "";
        if (queryObject.partition.length > 0) {
            partition = "&partition=" + queryObject.partition.join(",");
        }
        
        var filters = "";
        if (queryObject.filterColumn.length > 0) {
            var filterLength = queryObject.filterColumn.length;
            for (var i = 0; i < filterLength; i++) {
                filters += "&filterColumn=" + queryObject.filterColumn[i] + "&filterValue=" + queryObject.filterValue[i];
            }
        }
        //console.log(table + column + aggType + group + partition + filters);
        return table + column + aggType + group + partition + filters;
       
    }

    var createReportPost = function (reportObject) {
        var retunValue = {};
        retunValue.Report_Name = reportObject.name;
        retunValue.Report_Type = reportObject.roleType;
        retunValue.Report = reportObject;
        retunValue.GUID = reportObject.GUID;
        return retunValue;
    }

    
    //    DATA STRUCTURE
    //
    dataScope.DR = dataResource;
    dataScope.DO = dataObject;


    return dataScope;
});