﻿metricDashboard.controller('SeriesModal2', ['$scope', 'appStateManager', '$uibModalInstance', function ($scope, appStateManager, $uibModalInstance) {

	var OT = appStateManager.OT;
	$scope.DSD = appStateManager.DSD;
	$scope.canvases = appStateManager.DSD.product.canvases;
	$scope.dashboard = appStateManager.DSD.product.dashboard;

	$scope.ok = function () {
		$uibModalInstance.close();
	};

	$scope.availableColumnIndex = -1;
	$scope.availableColumnSelected = function (index) {
		$scope.availableColumnIndex = index;
	};
	$scope.currentColumnIndex = -1;
	$scope.currentColumnSelected = function (index) {
		$scope.currentColumnIndex = index;
	};
	$scope.addColumnToFilter = function () {
	    var element = $scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group].elements[$scope.dashboard.index.element];
	    var source = $scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group].elements[$scope.dashboard.index.element].chartOptions.result;

	    element.chartFunctions.addSeries(source[$scope.availableColumnIndex]);
	};
	$scope.removeColumnFromFilter = function () {
	    var element = $scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group].elements[$scope.dashboard.index.element];

	    element.chartFunctions.removeSeries(element.chart.options.series[$scope.currentColumnIndex].name);
	    element.chart.options.series.splice($scope.currentColumnIndex, 1);
	    //$scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group].elements[$scope.dashboard.index.element].chartOptions.series.splice($scope.currentColumnIndex, 1);
	    
	}

}]);