﻿mapApp.directive('chartProperties2', ['$uibModal', function ($uibModal) {

    return {
        templateUrl: 'shared-components/chart-properties2/chartProperties2.html',
        link: link,
        scope: {
            element: "=",
            group: "="
        }
    };

    function link(scope) {


        scope.openSeriesModal = function (size) {

            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'shared-components/chart-properties2/series-modal2.html',
                controller: 'SeriesModal2',
                size: size
            });
        }

        scope.test = function () {
            scope.element.chartFunctions.updateTitle('robert');
        }
       
    };
}]);