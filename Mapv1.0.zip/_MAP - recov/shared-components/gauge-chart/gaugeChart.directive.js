﻿mapApp.directive('gaugeChart', ['$timeout', function ($timeout) {
    return {
        scope: { data: "=" },
        restrict: 'E',
        link: link
    };

    function link(scope, element) {
        // the D3 bits..
        //$timeout(function () {
            var el = element[0];
            var chartOptions = {
                bindto: d3.select(el),
                data: {
                    columns: [
                        ['data', 71.4]
                    ],
                    type: 'gauge',
                    onclick: function (d, i) { console.log("onclick", d, i); },
                    onmouseover: function (d, i) { console.log("onmouseover", d, i); },
                    onmouseout: function (d, i) { console.log("onmouseout", d, i); }
                },
                color: {
                    pattern: ['#FF0000', '#F97600', '#F6C600', '#60B044'],
                    threshold: {
                        values: [30, 60, 90, 100]
                    }
                }
            };
            var chart = c3.generate(chartOptions);

            scope.$watch(function () { return el.parentNode.clientHeight * el.parentNode.clientWidth }, function () {
                chart.resize({ height: el.parentNode.clientHeight, width: el.parentNode.clientWidth });
            });




        //}, 1);


    }


}]);