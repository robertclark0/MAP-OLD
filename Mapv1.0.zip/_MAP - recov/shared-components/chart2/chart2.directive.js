﻿mapApp.directive('hcChart', function ($q) {
    return {
        restrict: 'E',
        scope: {
            data: "=",
            elementObject: "=element"
        },
        link: function (scope, element) {


            var chartOptions = {
                exporting: {
                    fallbackToExportServer: false
                },
                credits:{enabled: false},
                legend: {
                    layout: 'horizontal',
                    align: 'center',
                    verticalAlign: 'bottom',
                    borderWidth: 0
                },
                result: preProcess(scope.data),
                exporting: {
                    buttons: {
                        contextButton: {
                            menuItems: null,
                            onclick: function () {
                                this.exportChart();
                            }
                        }
                    }
                }
            };

            scope.elementObject.chartOptions = scope.elementObject.chartOptions || chartOptions;

            if (scope.elementObject.chart && scope.elementObject.chart.options) {
                scope.elementObject.chart = Highcharts.chart(element[0], scope.elementObject.chart.options);
            }
            else {
                scope.elementObject.chart = Highcharts.chart(element[0], scope.elementObject.chartOptions);
            }
            
                      
            scope.$watch(function () { return element[0].parentNode.clientHeight * element[0].parentNode.clientWidth }, function () {
                scope.elementObject.chart.setSize(element[0].parentNode.clientWidth, element[0].parentNode.clientHeight);
            });

            scope.$watch('elementObject.chartOptions', function () {
                console.log('options changed');
            }, true);

            scope.$watch('data', function () {
                scope.elementObject.chartOptions.result = preProcess(scope.data);
                console.log('data changed');
            }, true);


            function preProcess(initialArray) {
                if (initialArray && initialArray[0]) {
                    var keys = Object.keys(initialArray[0]);
                    var newArray = [];
                    keys.forEach(function (curKey) {
                        newArray.push({ name: curKey, data: [] });
                    });
                    initialArray.forEach(function (curObject) {
                        keys.forEach(function (curKey, index) {
                            newArray[index].data.push(curObject[curKey]);
                        });
                    });
                    return newArray;
                }
                return [];
            };

            var chartFunctions = {
                removeSeries: function (seriesName) {
                    var seriesIndex = scope.elementObject.chart.options.series.map(function (e) {
                        return e.name;
                    }).indexOf(seriesName);
                    scope.elementObject.chart.series[seriesIndex].remove();
                    
                },
                addSeries: function (seriesObject) {
                    scope.elementObject.chart.addSeries(seriesObject);
                    scope.elementObject.chart.options.series.push(seriesObject);
                    
                },
                updateTitle: function (newTitle) {
                    scope.elementObject.chart.setTitle({ text: newTitle });
                    console.log(scope.elementObject.chart.options);
                }
            };
            scope.elementObject.chartFunctions = chartFunctions;


        }
    };
})