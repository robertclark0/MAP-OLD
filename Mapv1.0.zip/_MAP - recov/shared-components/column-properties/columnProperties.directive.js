﻿mapApp.directive('columnProperties', function () {

    return {
        templateUrl: 'shared-components/column-properties/columnProperties.html',
        link: link,
        scope: {
            columnObject: "=",
            callFunction: "&"
        }
    };

    function link(scope) {

        scope.partition = function (columnProperty) {
            columnProperty.partition = !columnProperty.partition
            scope.callFunction()
        };
        scope.clicked = function () {
            scope.callFunction()
        }
    };

});