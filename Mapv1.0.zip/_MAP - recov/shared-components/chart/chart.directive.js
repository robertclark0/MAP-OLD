﻿mapApp.directive('chartElement', function ($q) {

    return {
        scope: {
            data: "=",
            elementObject: "=element"
        },
        restrict: 'E',
        link: link,
    };

    function link(scope, elem) {

        var el = elem[0];
        var chart;
        var chartOptions = {
            data: {
                json: scope.data,
                keys: {
                    x: '',
                    value: [],
                },
                groups: [

                    //['GQ', 'GT', 'Hub', 'Provider_Modifier_----']
                ],
                type: 'bar',
                labels: false
            },
            color: {
                //pattern: ['#1f77b4', '#aec7e8']
                //threshold.values: [30, 60, 90, 100]
            },
            interaction: { enabled: true },
            axis: {
                rotated: false,
                x: { show: true, tick: { rotate: 0 }, max: undefined, min: undefined, type: 'category' },
                y: { show: true, max: undefined, min: undefined }
            },
            padding: { top: undefined, bottom: undefined, left: undefined, right: undefined },
            grid: { x: { show: false }, y: { show: false } },
            legend: { show: true, position: 'bottom' },
            tooltip: { show: true, grouped: true },
            point: { show: true, r: 2.5, focus: { expand: { r: 4 } } },
            bar: { width: { ratio: 0.75 } },
            pie: { label: { show: true }, expand: true },
            donut: { label: { show: true }, expand: true },
            gauge: { label: { show: true }, expand: true, min: 0, max: 100, }
        };
        var chartFunctions = {
            transform: function (newValue) {
                chart.transform(newValue);
                scope.elementObject.chartOptions.data.type = newValue;
            },
            toggleLegend: function (bool) {
                if (bool) {
                    chart.legend.show();
                }
                else {
                    chart.legend.hide();
                }
            },
            axisMin: function (axisValueObject) {
                chart.axis.min(axisValueObject);
                if (axisValueObject.x) {
                    scope.elementObject.chartOptions.axis.x.min = axisValueObject.x;
                }
            },
            axisMax: function (axisValueObject) {
                chart.axis.max(axisValueObject);
                if (axisValueObject.x) {
                    scope.elementObject.chartOptions.axis.x.max = axisValueObject.x;
                }
            }
        };

        scope.elementObject.chartOptions = scope.elementObject.chartOptions || chartOptions;
        scope.elementObject.chartFunctions = chartFunctions;


        scope.$watchGroup([
            'elementObject.chartOptions.legend.position',
            'elementObject.chartOptions.interaction.enabled',
            'elementObject.chartOptions.axis.rotated',
            'elementObject.chartOptions.axis.x.tick.rotate',
            'elementObject.chartOptions.axis.x.show',
            'elementObject.chartOptions.axis.x.min',
            'elementObject.chartOptions.axis.x.max',
            'elementObject.chartOptions.axis.y.show',
            'elementObject.chartOptions.axis.y.min',
            'elementObject.chartOptions.axis.y.max',
            'elementObject.chartOptions.grid.x.show',
            'elementObject.chartOptions.grid.y.show',
            'elementObject.chartOptions.tooltip.show',
            'elementObject.chartOptions.tooltip.grouped',
            'elementObject.chartOptions.data.labels',
            'elementObject.chartOptions.padding.top',
            'elementObject.chartOptions.padding.bottom',
            'elementObject.chartOptions.padding.left',
            'elementObject.chartOptions.padding.right',
            'elementObject.chartOptions.point.show',
            'elementObject.chartOptions.point.r',
            'elementObject.chartOptions.point.focus.expand.r',
            'elementObject.chartOptions.bar.width.ratio',
            'elementObject.chartOptions.pie.label.show',
            'elementObject.chartOptions.pie.expand',
            'elementObject.chartOptions.donut.label.show',
            'elementObject.chartOptions.donut.expand',
            'elementObject.chartOptions.gauge.label.show',
            'elementObject.chartOptions.gauge.expand',
            'elementObject.chartOptions.gauge.min',
            'elementObject.chartOptions.gauge.max',
            'elementObject.chartOptions.data.keys.x',
            'elementObject.chartOptions.data.keys.value'
        ], function () {
            generate()
            render();
            resize()

        });
        scope.$watch(function () { return el.parentNode.clientHeight * el.parentNode.clientWidth }, function () {
            resize()
        });
        scope.$watch('data', function () {
            chart.load({ json: scope.data, keys: scope.elementObject.chartOptions.data.keys });
        }, true);
        scope.$watch('elementObject.chartOptions.data.groups', function () {
            generate()
            render();
            resize()
        }, true);
        scope.$watch('elementObject.chartOptions.data.keys.value', function () {
            generate()
            render();
            resize()
        }, true);


        function generate() {
            chart = c3.generate(scope.elementObject.chartOptions);
            //var doc = document;
            //console.log("web worker started: ");
            //callWebWorker({chart: scope.elementObject.chartOptions}).then(function (reply) {
            //    console.log(reply.element);
            // });
        };
        function render() {
            elem.html(chart.element);

        };
        function resize() {
            chart.resize({ height: el.parentNode.clientHeight, width: el.parentNode.clientWidth });
            chart.load({ json: scope.data, keys: scope.elementObject.chartOptions.data.keys });
        }
        function callWebWorker(message) {
            var worker = new Worker('shared-components/chart/worker.js');
            var defer = $q.defer();
            worker.onmessage = function (e) {
                defer.resolve(e.data);
                worker.terminate();
            }

            worker.postMessage(message);
            return defer.promise;
        }

        generate()
        render();
        //resize()
        

    };
});