﻿mapApp.directive('chartProperties', ['$uibModal', function ($uibModal) {

    return {
        templateUrl: 'shared-components/chart-properties/chartProperties.html',
        link: link,
        scope: {
            element: "=",
            group: "="
        }
    };

    function link(scope) {

        scope.openSeriesModal = function (size) {

            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'shared-components/chart-properties/series-modal.html',
                controller: 'SeriesModal',
                size: size
            });
        }
        scope.openStackModal = function (size) {

            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'shared-components/chart-properties/stack-modal.html',
                controller: 'StackModal',
                size: size
            });
        }

        scope.boolShow = function (bool) { if (bool) { return 'Show'; } return 'Hide'; };
        scope.boolOn = function (bool) { if (bool) { return 'On'; } return 'Off'; };
        scope.boolRotated = function (bool) { if (bool) { return 'Rotated'; } return 'Standard'; };

        scope.types = ['line', 'spline', 'step', 'area', 'area-spline', 'area-step', 'bar', 'scatter', 'pie', 'donut', 'gauge'];
        scope.legendPosition = ['bottom', 'right', 'inset'];

        scope.posSelected = function (pos) {
            scope.element.chartOptions.legend.position = pos;
        };
        scope.axisRange = function (newValue, location) {
            if (newValue === '') {
                newValue = undefined;
            }
            else {
                newValue = parseFloat(newValue);
            }
            switch (location) {
                case 'x.min':
                    scope.element.chartOptions.axis.x.min = newValue;
                    break;
                case 'y.min':
                    scope.element.chartOptions.axis.y.min = newValue;
                    break;
                case 'x.max':
                    scope.element.chartOptions.axis.x.max = newValue;
                    break;
                case 'y.max':
                    scope.element.chartOptions.axis.y.max = newValue;
                    break;
            }
        };
        scope.padding = function (newValue, location) {
            if (newValue === '') {
                newValue = undefined;
            }
            else {
                newValue = parseFloat(newValue);
            }
            switch (location) {
                case 'top':
                    scope.element.chartOptions.padding.top = newValue;
                    break;
                case 'bottom':
                    scope.element.chartOptions.padding.bottom = newValue;
                    break;
                case 'left':
                    scope.element.chartOptions.padding.left = newValue;
                    break;
                case 'right':
                    scope.element.chartOptions.padding.right = newValue;
                    break;
            }
        };



    };
}]);