﻿metricDashboard.controller('StackModal', ['$scope', 'appStateManager', '$uibModalInstance', function ($scope, appStateManager, $uibModalInstance) {

    var OT = appStateManager.OT;
    $scope.DSD = appStateManager.DSD;
    $scope.canvases = appStateManager.DSD.product.canvases;
    $scope.dashboard = appStateManager.DSD.product.dashboard;

    $scope.currentColumnIndex = -1;
    $scope.currentColumnSelected = function (index) {
        $scope.currentColumnIndex = index;
    };

    $scope.ok = function () {
        $uibModalInstance.close();
    };

    $scope.inItems = function () { return Object.keys($scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group].data.result[0]); };
    $scope.outItems = [];
    
    $scope.createStack = function () {
        $scope.stackArray = $scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group].elements[$scope.dashboard.index.element].chartOptions.data.groups;

        var tempArray = [];
        $scope.outItems.forEach(function (entry) {
            tempArray.push(entry);
        });
        $scope.stackArray.push(tempArray);
    };

    $scope.deleteStack = function () {
        $scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group].elements[$scope.dashboard.index.element].chartOptions.data.groups.splice($scope.currentColumnIndex, 1);
    };



}]);