﻿metricDashboard.controller('SeriesModal', ['$scope', 'appStateManager', '$uibModalInstance', function ($scope, appStateManager, $uibModalInstance) {

	var OT = appStateManager.OT;
	$scope.DSD = appStateManager.DSD;
	$scope.canvases = appStateManager.DSD.product.canvases;
	$scope.dashboard = appStateManager.DSD.product.dashboard;

	$scope.ok = function () {
		$uibModalInstance.close();
	};

	$scope.availableColumnIndex = -1;
	$scope.availableColumnSelected = function (index) {
		$scope.availableColumnIndex = index;
	};
	$scope.currentColumnIndex = -1;
	$scope.currentColumnSelected = function (index) {
		$scope.currentColumnIndex = index;
	};
	$scope.addColumnToFilter = function () {
		var target = $scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group].elements[$scope.dashboard.index.element].chartOptions.data.keys.value
		var source = Object.keys($scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group].data.result[0]);
		target.push(source[$scope.availableColumnIndex]);

	};
	$scope.removeColumnFromFilter = function () {
		$scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group].elements[$scope.dashboard.index.element].chartOptions.data.keys.value.splice($scope.currentColumnIndex, 1);
	}

}]);