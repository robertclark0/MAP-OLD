﻿mapApp.directive('header', function () {
	    return {
	        templateUrl: 'shared-components/header/header.html',
	        restrict: 'E',
	        replace: true
	    }
});
