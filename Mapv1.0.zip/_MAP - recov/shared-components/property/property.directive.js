﻿mapApp.directive('property', ['$compile', function ($compile) {
    return {
        restrict: 'E',
        scope: {
            propertyObject: "="
        },
        link: link
    };

    function link(scope, elem, attr) {

        var compileString = '';

        switch (scope.propertyObject.type) {
            case 'string':               
                compileString = '<input type="text" class="form-control" style="border-radius:0;" ng-model="propertyObject.value" />';
                break;

            case 'bool':
                compileString = '<toggle-switch bool-object="propertyObject"></toggle-switch>';
                break;

            case 'multiline':
                compileString = '<textarea rows="20" class="form-control" ng-model="propertyObject.value"></textarea>';
                break;
        }

        elem.replaceWith($compile(compileString)(scope));

    }

}]);