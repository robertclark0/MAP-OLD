﻿mapApp.directive('titleBlock', function () {

    return {
        templateUrl: 'shared-components/titleBlock/titleBlock.html',
        link: link,
        scope: {
            element: "="
        }
    };

    function link(scope) {

        var template = [
            { name: 'title', type: 'string', value: 'Title' },
            { name: 'subtitle', type: 'string', value: 'Subtitle' },
            { name: 'Show Subtitle', type: 'bool', value: true }
        ];

        scope.element.properties = scope.element.properties || angular.copy(template);

    };
});