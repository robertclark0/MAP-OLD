﻿mapApp.directive('donutChart', ['$timeout', function ($timeout) {
    return {
        scope: { data: "="},
        restrict: 'E',
        link: link
    };

    function link(scope, element) {
        // the D3 bits..
        $timeout(function () {

            //var data = [1, 2, 3, 4];
            var color = d3.scale.category10();
            var el = element[0];
            var pie = d3.layout.pie().sort(null);
            var arc = d3.svg.arc();
            var svg = d3.select(el).append('svg');
            var g = svg.append('g');
            var arcs = g.selectAll('path').data(pie(scope.data)).enter().append('path').style('stroke', 'white').attr('fill', function (d, i) { return color(i) });

            scope.$watch(function () { return el.parentNode.clientHeight * el.parentNode.clientWidth }, function () {

                var width = el.parentNode.clientWidth;
                var height = el.parentNode.clientHeight;
                var min = Math.min(width, height);
                arc.outerRadius(min / 2 * 0.9).innerRadius(min / 2 * 0.45);
                svg.attr({ width: width, height: height });
                g.attr('transform', 'translate(' + width / 2 + ',' + height / 2 + ')');
                arcs.attr('d', arc);
            });


        }, 500);


    }


}]);