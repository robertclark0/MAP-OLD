﻿metricDashboard.factory('appStateManager', function ($rootScope, $sessionStorage, dataManager) {

    var DO = dataManager.DO;

    //    OBJECT TEMPLATES
    //
    var objectTempaltes = {};

    objectTempaltes.Data = { productLine: { current: "none", previous: "none" }, role: 2 };
    objectTempaltes.ProductLine = { name: '', dashboard: { toggleRight: false, panelLeftHidden: false, panelRightHidden: false, mode: 'Reporting', modeView: 'Canvas', index: { report: 0, userReport: 0, canvas: 0, group: -1, element: -1, filter: -1 } }, reports: [], userReports: [], canvases: [{ name: 'Canvas', roleType: 'User', overwrite: false, fromDB: false, GUID: null, dataGroups: [] }] };
    objectTempaltes.Canvas = { name: 'Canvas', roleType: 'User', overwrite: false, fromDB: false, GUID: null, dataGroups: [] };
    objectTempaltes.Group = {
        name: '', dataSource: '', filters: [], elements: [], data: {
            result: [], tableColumns: [], columnProperties: [], query: {
                table: "Telehealth_360_CAPER",
                column: [],
                group: [],
                aggTypes: [],
                partition: [],
                filterColumn: [],
                filterValue: []
            },
            calc: { column1: "", column2: "", operator: "", as: "" }
        }
    };
    objectTempaltes.Filter = { name: '', visibleInReport: true, selectedValues: [], selectToggle: 0 };
    objectTempaltes.Element = { name: '', type: '', width: 4, height: 3 };
    objectTempaltes.columnProperty = {column: '', aggregate: 'none', partition: false, grouped: false};


    //    DATA OBJECT FUNCTIONS
    //
    var dataObjectFunctions = {};

    dataObjectFunctions.getProductLine = function () {
        return session.data.productLine.current;
    };
    dataObjectFunctions.setProductLine = function (product) {
        session.data.productLine.previous = session.data.productLine.current;
        session.data.productLine.current = product.dataName;

        session.data[product.dataName] = session.data[product.dataName] || angular.copy(objectTempaltes.ProductLine);
        session.data[product.dataName].canvases[0].GUID = session.data[product.dataName].canvases[0].GUID || dataObjectFunctions.generateGUID();
        session.data[product.dataName].name = product.name;
        //DataManager
        DO[product.dataName] = DO[product.dataName] || { dataQueries: [], filters: [] };


    };
    dataObjectFunctions.toggleCanvasPanel = function () {
        var id = event.target.id;
        var dashboard = session.dynamicStateData.product.dashboard;
        if (id === "togglePanelLeft") {
            dashboard.panelLeftHidden = !dashboard.panelLeftHidden;
        } else if (id === "togglePanelRight") {
            dashboard.panelRightHidden = !dashboard.panelRightHidden;
        } else if (id === "togglePresentation") {
            dashboard.panelLeftHidden = true;
            dashboard.panelRightHidden = true;
        }

        var evt = window.document.createEvent('UIEvents');
        evt.initUIEvent('resize', true, false, window, 0);
        window.dispatchEvent(evt);

    };
    dataObjectFunctions.generateGUID = function () {
        var d = new Date().getTime();
        if (window.performance && typeof window.performance.now === "function") {
            d += performance.now(); //use high-precision timer if available
        }
        var GUID = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = (d + Math.random() * 16) % 16 | 0;
            d = Math.floor(d / 16);
            return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
        });
        return GUID;
    }
    var generateGUID = function () {
        var d = new Date().getTime();
        if (window.performance && typeof window.performance.now === "function") {
            d += performance.now(); //use high-precision timer if available
        }
        var GUID = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = (d + Math.random() * 16) % 16 | 0;
            d = Math.floor(d / 16);
            return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
        });
        return GUID;
    };



    //    DATA STUCTURES
    //
    var stateScope = $rootScope.$new(true);

    var session = $sessionStorage;
    session.data = session.data || angular.copy(objectTempaltes.Data);
    session.dynamicStateData = session.dynamicStateData || {};

    stateScope.DSD = session.dynamicStateData;
    stateScope.D = session.data;
    stateScope.OT = objectTempaltes;
    stateScope.DOF = dataObjectFunctions;



    return stateScope;
});