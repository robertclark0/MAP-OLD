﻿mapApp.directive('toggleSwitch', function () {

    return {
        templateUrl: 'shared-components/toggleSwitch/toggleSwitch.html',
        replace: true,
        link: link,
        scope: {
            boolObject: "="
        }
    };

    function link(scope) {

    };
});