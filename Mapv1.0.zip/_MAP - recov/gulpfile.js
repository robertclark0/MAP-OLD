﻿// Include gulp
var gulp = require('gulp');
// Include plugins
var concat = require('gulp-concat');
var order = require('gulp-order');
// Concatenate JS Files
gulp.task('scripts-libs', function () {
    return gulp.src([
        'libs/jquery/jquery.min.js',
        'libs/angular/angular.min.js',
        'libs/angular-resource/angular-resource.js',
        'libs/angular-animate/angular-animate.js',
        'libs/angular-ui-router/angular-ui-router.min.js',
        'libs/angular-css/angular-css.min.js',
        'libs/angular-sanitize/angular-sanitize.min.js',
        'libs/bootstrap/bootstrap.min.js',
        'libs/angular-ui-bootstrap/ui-bootstrap-tpls-1.1.1.min.js',
        'libs/jquery.scrollbar/jquery.scrollbar.min.js',
        'libs/slick/slick.min.js',
        'libs/angular-slick/slick.min.js',
        'libs/angular-gridster/angular-gridster.min.js',
        'libs/ngStorage/ngStorage.min.js',
        'libs/jqueryUI/jqueryUI.min.js',
        'libs/forDemo/d3.min.js',
        'libs/forDemo/c3.js',
        'libs/forDemo/c3-angular.min.js',
        'libs/highcharts/highcharts.js',
        'libs/highcharts/exporting.js',
        'libs/highcharts/offline-exporting.js'
    ])
      .pipe(concat('libraries.min.js'))
      .pipe(gulp.dest('assets/js'));
});

gulp.task('scripts-app', function () {
    return gulp.src([
        '!shared-components/chart/worker.js',
        'app/app.module.js',
        'app/app.config.js',
        'app/app.controller.js',
        'core-components/**/*.js',
        'shared-components/**/*.js'
    ])
      .pipe(order([
          'app.module.js',
          '**/module.js'
      ]))
      .pipe(concat('app.js'))
      .pipe(gulp.dest('assets/js'));
});

gulp.task('css-app', function () {
    return gulp.src([
        'libs/bootstrap/bootstrap.min.css',
        'libs/jquery.scrollbar/jquery.scrollbar.css',
        'libs/slick/slick.css',
        'libs/angular-gridster/angular-gridster.min.css',
        'libs/forDemo/c3.min.css',
        'libs/ng-c3-export/ng-c3-export.css',
        'assets/css/**/*.css',
        '!assets/css/style.css',
        'shared-components/**/*.css'
    ])
      .pipe(concat('style.css'))
      .pipe(gulp.dest('assets/css'));
});


// Default Task
gulp.task('default', ['scripts-libs', 'scripts-app', 'css-app']);