var mapApp = angular.module('mapApp', [
    'ui.router',
    'door3.css',
    'slick',
    'jQueryScrollbar',
    'platformHome',
    'metricDashboard',
    'gridster',
    'ngStorage',
    'ui.bootstrap'
]);
var metricDashboard = angular.module('metricDashboard', ['ngResource']);
var platformHome = angular.module('platformHome', []);
mapApp.config(function ($stateProvider, $urlRouterProvider) {
    
    $urlRouterProvider.otherwise("/platform-home/product-lines");

    $stateProvider
        .state("platformHome", {
            url: "/platform-home",
            templateUrl: "core-components/platform-home/view.html",
            css: { href: "core-components/platform-home/style.css" },
            controller: "PlatformHome"
        })
        .state("platformHome.productLines", {
            url: "/product-lines",
            templateUrl: "core-components/platform-home/templates/product-lines.html",
            css: { href: "core-components/platform-home/style.css" },
            controller: "PlatformHome"
        })
        .state("platformHome.about", {
            url: "/about",
            templateUrl: "core-components/platform-home/templates/about.html",
            css: { href: "core-components/platform-home/style.css" }
        })
        .state("metricDashboardReporting", {
            url: "/metric-dashboard/reporting",
            css: { href: "core-components/metric-dashboard/style.css" },
            views: {
                "": {
                    templateUrl: "core-components/metric-dashboard/view.html",
                    controller: 'MetricDashboard',
                },
                "left@metricDashboardReporting": {
                    templateUrl: "core-components/metric-dashboard/templates/report-left.html",
                    controller: "MetricDashboardReportLeft"
                },
                "canvas@metricDashboardReporting": {
                    templateUrl: "core-components/metric-dashboard/templates/report.html",
                    controller: "MetricDashboardCanvas"
                },
                "right@metricDashboardReporting": {
                    template: "<div></div>",
                }
            }
        })
        .state("metricDashboard", {
            url: "/metric-dashboard",
            css: { href: "core-components/metric-dashboard/style.css" },
            views: {
                "": {
                    templateUrl: "core-components/metric-dashboard/view.html",
                    controller: 'MetricDashboard',
                },
                "left@metricDashboard": {
                    templateUrl: "core-components/metric-dashboard/templates/left.html",
                    controller: "MetricDashboardLeft",
                },
                "canvas@metricDashboard": {
                    templateUrl: "core-components/metric-dashboard/templates/canvas.html",
                    controller: "MetricDashboardCanvas"
                },
                "right@metricDashboard": {
                    templateUrl: "core-components/metric-dashboard/templates/right.html",
                    controller: "MetricDashboardRight"
                }
            }
        })
        .state("metricDashboard.grid", {
            css: { href: "core-components/metric-dashboard/style.css" },
            views: {
                "canvas@metricDashboard": {
                    templateUrl: "core-components/metric-dashboard/templates/grid.html",
                    controller: "MetricDashboardCanvas"
                }
            }
        })
        .state("metricDashboard.canvas", {
            css: { href: "core-components/metric-dashboard/style.css" },
            views: {
                "canvas@metricDashboard": {
                    templateUrl: "core-components/metric-dashboard/templates/canvas.html",
                    controller: "MetricDashboardCanvas"
                }
            }
        });

});
mapApp.controller('MainController', ['$scope', function ($scope) {

    $scope.testValue01 = "AngularJS is Working";
    $scope.testValue02 = "AngularJS is Still Working";


}]);
metricDashboard.factory('appStateManager', function ($rootScope, $sessionStorage, dataManager) {

    var DO = dataManager.DO;

    //    OBJECT TEMPLATES
    //
    var objectTempaltes = {};

    objectTempaltes.Data = { productLine: { current: "none", previous: "none" }, role: 2 };
    objectTempaltes.ProductLine = { name: '', dashboard: { toggleRight: false, panelLeftHidden: false, panelRightHidden: false, mode: 'Reporting', modeView: 'Canvas', index: { report: 0, userReport: 0, canvas: 0, group: -1, element: -1, filter: -1 } }, reports: [], userReports: [], canvases: [{ name: 'Canvas', roleType: 'User', overwrite: false, fromDB: false, GUID: null, dataGroups: [] }] };
    objectTempaltes.Canvas = { name: 'Canvas', roleType: 'User', overwrite: false, fromDB: false, GUID: null, dataGroups: [] };
    objectTempaltes.Group = {
        name: '', dataSource: '', filters: [], elements: [], data: {
            result: [], tableColumns: [], columnProperties: [], query: {
                table: "Telehealth_360_CAPER",
                column: [],
                group: [],
                aggTypes: [],
                partition: [],
                filterColumn: [],
                filterValue: []
            },
            calc: { column1: "", column2: "", operator: "", as: "" }
        }
    };
    objectTempaltes.Filter = { name: '', visibleInReport: true, selectedValues: [], selectToggle: 0 };
    objectTempaltes.Element = { name: '', type: '', width: 4, height: 3 };
    objectTempaltes.columnProperty = {column: '', aggregate: 'none', partition: false, grouped: false};


    //    DATA OBJECT FUNCTIONS
    //
    var dataObjectFunctions = {};

    dataObjectFunctions.getProductLine = function () {
        return session.data.productLine.current;
    };
    dataObjectFunctions.setProductLine = function (product) {
        session.data.productLine.previous = session.data.productLine.current;
        session.data.productLine.current = product.dataName;

        session.data[product.dataName] = session.data[product.dataName] || angular.copy(objectTempaltes.ProductLine);
        session.data[product.dataName].canvases[0].GUID = session.data[product.dataName].canvases[0].GUID || dataObjectFunctions.generateGUID();
        session.data[product.dataName].name = product.name;
        //DataManager
        DO[product.dataName] = DO[product.dataName] || { dataQueries: [], filters: [] };


    };
    dataObjectFunctions.toggleCanvasPanel = function () {
        var id = event.target.id;
        var dashboard = session.dynamicStateData.product.dashboard;
        if (id === "togglePanelLeft") {
            dashboard.panelLeftHidden = !dashboard.panelLeftHidden;
        } else if (id === "togglePanelRight") {
            dashboard.panelRightHidden = !dashboard.panelRightHidden;
        } else if (id === "togglePresentation") {
            dashboard.panelLeftHidden = true;
            dashboard.panelRightHidden = true;
        }

        var evt = window.document.createEvent('UIEvents');
        evt.initUIEvent('resize', true, false, window, 0);
        window.dispatchEvent(evt);

    };
    dataObjectFunctions.generateGUID = function () {
        var d = new Date().getTime();
        if (window.performance && typeof window.performance.now === "function") {
            d += performance.now(); //use high-precision timer if available
        }
        var GUID = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = (d + Math.random() * 16) % 16 | 0;
            d = Math.floor(d / 16);
            return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
        });
        return GUID;
    }
    var generateGUID = function () {
        var d = new Date().getTime();
        if (window.performance && typeof window.performance.now === "function") {
            d += performance.now(); //use high-precision timer if available
        }
        var GUID = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = (d + Math.random() * 16) % 16 | 0;
            d = Math.floor(d / 16);
            return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
        });
        return GUID;
    };



    //    DATA STUCTURES
    //
    var stateScope = $rootScope.$new(true);

    var session = $sessionStorage;
    session.data = session.data || angular.copy(objectTempaltes.Data);
    session.dynamicStateData = session.dynamicStateData || {};

    stateScope.DSD = session.dynamicStateData;
    stateScope.D = session.data;
    stateScope.OT = objectTempaltes;
    stateScope.DOF = dataObjectFunctions;



    return stateScope;
});
mapApp.directive('chartProperties', ['$uibModal', function ($uibModal) {

    return {
        templateUrl: 'shared-components/chart-properties/chartProperties.html',
        link: link,
        scope: {
            element: "=",
            group: "="
        }
    };

    function link(scope) {

        scope.openSeriesModal = function (size) {

            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'shared-components/chart-properties/series-modal.html',
                controller: 'SeriesModal',
                size: size
            });
        }
        scope.openStackModal = function (size) {

            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'shared-components/chart-properties/stack-modal.html',
                controller: 'StackModal',
                size: size
            });
        }

        scope.boolShow = function (bool) { if (bool) { return 'Show'; } return 'Hide'; };
        scope.boolOn = function (bool) { if (bool) { return 'On'; } return 'Off'; };
        scope.boolRotated = function (bool) { if (bool) { return 'Rotated'; } return 'Standard'; };

        scope.types = ['line', 'spline', 'step', 'area', 'area-spline', 'area-step', 'bar', 'scatter', 'pie', 'donut', 'gauge'];
        scope.legendPosition = ['bottom', 'right', 'inset'];

        scope.posSelected = function (pos) {
            scope.element.chartOptions.legend.position = pos;
        };
        scope.axisRange = function (newValue, location) {
            if (newValue === '') {
                newValue = undefined;
            }
            else {
                newValue = parseFloat(newValue);
            }
            switch (location) {
                case 'x.min':
                    scope.element.chartOptions.axis.x.min = newValue;
                    break;
                case 'y.min':
                    scope.element.chartOptions.axis.y.min = newValue;
                    break;
                case 'x.max':
                    scope.element.chartOptions.axis.x.max = newValue;
                    break;
                case 'y.max':
                    scope.element.chartOptions.axis.y.max = newValue;
                    break;
            }
        };
        scope.padding = function (newValue, location) {
            if (newValue === '') {
                newValue = undefined;
            }
            else {
                newValue = parseFloat(newValue);
            }
            switch (location) {
                case 'top':
                    scope.element.chartOptions.padding.top = newValue;
                    break;
                case 'bottom':
                    scope.element.chartOptions.padding.bottom = newValue;
                    break;
                case 'left':
                    scope.element.chartOptions.padding.left = newValue;
                    break;
                case 'right':
                    scope.element.chartOptions.padding.right = newValue;
                    break;
            }
        };



    };
}]);
metricDashboard.controller('SeriesModal', ['$scope', 'appStateManager', '$uibModalInstance', function ($scope, appStateManager, $uibModalInstance) {

	var OT = appStateManager.OT;
	$scope.DSD = appStateManager.DSD;
	$scope.canvases = appStateManager.DSD.product.canvases;
	$scope.dashboard = appStateManager.DSD.product.dashboard;

	$scope.ok = function () {
		$uibModalInstance.close();
	};

	$scope.availableColumnIndex = -1;
	$scope.availableColumnSelected = function (index) {
		$scope.availableColumnIndex = index;
	};
	$scope.currentColumnIndex = -1;
	$scope.currentColumnSelected = function (index) {
		$scope.currentColumnIndex = index;
	};
	$scope.addColumnToFilter = function () {
		var target = $scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group].elements[$scope.dashboard.index.element].chartOptions.data.keys.value
		var source = Object.keys($scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group].data.result[0]);
		target.push(source[$scope.availableColumnIndex]);

	};
	$scope.removeColumnFromFilter = function () {
		$scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group].elements[$scope.dashboard.index.element].chartOptions.data.keys.value.splice($scope.currentColumnIndex, 1);
	}

}]);
metricDashboard.controller('StackModal', ['$scope', 'appStateManager', '$uibModalInstance', function ($scope, appStateManager, $uibModalInstance) {

    var OT = appStateManager.OT;
    $scope.DSD = appStateManager.DSD;
    $scope.canvases = appStateManager.DSD.product.canvases;
    $scope.dashboard = appStateManager.DSD.product.dashboard;

    $scope.currentColumnIndex = -1;
    $scope.currentColumnSelected = function (index) {
        $scope.currentColumnIndex = index;
    };

    $scope.ok = function () {
        $uibModalInstance.close();
    };

    $scope.inItems = function () { return Object.keys($scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group].data.result[0]); };
    $scope.outItems = [];
    
    $scope.createStack = function () {
        $scope.stackArray = $scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group].elements[$scope.dashboard.index.element].chartOptions.data.groups;

        var tempArray = [];
        $scope.outItems.forEach(function (entry) {
            tempArray.push(entry);
        });
        $scope.stackArray.push(tempArray);
    };

    $scope.deleteStack = function () {
        $scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group].elements[$scope.dashboard.index.element].chartOptions.data.groups.splice($scope.currentColumnIndex, 1);
    };



}]);
mapApp.directive('chartProperties2', ['$uibModal', function ($uibModal) {

    return {
        templateUrl: 'shared-components/chart-properties2/chartProperties2.html',
        link: link,
        scope: {
            element: "=",
            group: "="
        }
    };

    function link(scope) {


        scope.openSeriesModal = function (size) {

            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'shared-components/chart-properties2/series-modal2.html',
                controller: 'SeriesModal2',
                size: size
            });
        }

        scope.test = function () {
            scope.element.chartFunctions.updateTitle('robert');
        }
       
    };
}]);
metricDashboard.controller('SeriesModal2', ['$scope', 'appStateManager', '$uibModalInstance', function ($scope, appStateManager, $uibModalInstance) {

	var OT = appStateManager.OT;
	$scope.DSD = appStateManager.DSD;
	$scope.canvases = appStateManager.DSD.product.canvases;
	$scope.dashboard = appStateManager.DSD.product.dashboard;

	$scope.ok = function () {
		$uibModalInstance.close();
	};

	$scope.availableColumnIndex = -1;
	$scope.availableColumnSelected = function (index) {
		$scope.availableColumnIndex = index;
	};
	$scope.currentColumnIndex = -1;
	$scope.currentColumnSelected = function (index) {
		$scope.currentColumnIndex = index;
	};
	$scope.addColumnToFilter = function () {
	    var element = $scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group].elements[$scope.dashboard.index.element];
	    var source = $scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group].elements[$scope.dashboard.index.element].chartOptions.result;

	    element.chartFunctions.addSeries(source[$scope.availableColumnIndex]);
	};
	$scope.removeColumnFromFilter = function () {
	    var element = $scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group].elements[$scope.dashboard.index.element];

	    element.chartFunctions.removeSeries(element.chart.options.series[$scope.currentColumnIndex].name);
	    element.chart.options.series.splice($scope.currentColumnIndex, 1);
	    //$scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group].elements[$scope.dashboard.index.element].chartOptions.series.splice($scope.currentColumnIndex, 1);
	    
	}

}]);
mapApp.directive('chartElement', function ($q) {

    return {
        scope: {
            data: "=",
            elementObject: "=element"
        },
        restrict: 'E',
        link: link,
    };

    function link(scope, elem) {

        var el = elem[0];
        var chart;
        var chartOptions = {
            data: {
                json: scope.data,
                keys: {
                    x: '',
                    value: [],
                },
                groups: [

                    //['GQ', 'GT', 'Hub', 'Provider_Modifier_----']
                ],
                type: 'bar',
                labels: false
            },
            color: {
                //pattern: ['#1f77b4', '#aec7e8']
                //threshold.values: [30, 60, 90, 100]
            },
            interaction: { enabled: true },
            axis: {
                rotated: false,
                x: { show: true, tick: { rotate: 0 }, max: undefined, min: undefined, type: 'category' },
                y: { show: true, max: undefined, min: undefined }
            },
            padding: { top: undefined, bottom: undefined, left: undefined, right: undefined },
            grid: { x: { show: false }, y: { show: false } },
            legend: { show: true, position: 'bottom' },
            tooltip: { show: true, grouped: true },
            point: { show: true, r: 2.5, focus: { expand: { r: 4 } } },
            bar: { width: { ratio: 0.75 } },
            pie: { label: { show: true }, expand: true },
            donut: { label: { show: true }, expand: true },
            gauge: { label: { show: true }, expand: true, min: 0, max: 100, }
        };
        var chartFunctions = {
            transform: function (newValue) {
                chart.transform(newValue);
                scope.elementObject.chartOptions.data.type = newValue;
            },
            toggleLegend: function (bool) {
                if (bool) {
                    chart.legend.show();
                }
                else {
                    chart.legend.hide();
                }
            },
            axisMin: function (axisValueObject) {
                chart.axis.min(axisValueObject);
                if (axisValueObject.x) {
                    scope.elementObject.chartOptions.axis.x.min = axisValueObject.x;
                }
            },
            axisMax: function (axisValueObject) {
                chart.axis.max(axisValueObject);
                if (axisValueObject.x) {
                    scope.elementObject.chartOptions.axis.x.max = axisValueObject.x;
                }
            }
        };

        scope.elementObject.chartOptions = scope.elementObject.chartOptions || chartOptions;
        scope.elementObject.chartFunctions = chartFunctions;


        scope.$watchGroup([
            'elementObject.chartOptions.legend.position',
            'elementObject.chartOptions.interaction.enabled',
            'elementObject.chartOptions.axis.rotated',
            'elementObject.chartOptions.axis.x.tick.rotate',
            'elementObject.chartOptions.axis.x.show',
            'elementObject.chartOptions.axis.x.min',
            'elementObject.chartOptions.axis.x.max',
            'elementObject.chartOptions.axis.y.show',
            'elementObject.chartOptions.axis.y.min',
            'elementObject.chartOptions.axis.y.max',
            'elementObject.chartOptions.grid.x.show',
            'elementObject.chartOptions.grid.y.show',
            'elementObject.chartOptions.tooltip.show',
            'elementObject.chartOptions.tooltip.grouped',
            'elementObject.chartOptions.data.labels',
            'elementObject.chartOptions.padding.top',
            'elementObject.chartOptions.padding.bottom',
            'elementObject.chartOptions.padding.left',
            'elementObject.chartOptions.padding.right',
            'elementObject.chartOptions.point.show',
            'elementObject.chartOptions.point.r',
            'elementObject.chartOptions.point.focus.expand.r',
            'elementObject.chartOptions.bar.width.ratio',
            'elementObject.chartOptions.pie.label.show',
            'elementObject.chartOptions.pie.expand',
            'elementObject.chartOptions.donut.label.show',
            'elementObject.chartOptions.donut.expand',
            'elementObject.chartOptions.gauge.label.show',
            'elementObject.chartOptions.gauge.expand',
            'elementObject.chartOptions.gauge.min',
            'elementObject.chartOptions.gauge.max',
            'elementObject.chartOptions.data.keys.x',
            'elementObject.chartOptions.data.keys.value'
        ], function () {
            generate()
            render();
            resize()

        });
        scope.$watch(function () { return el.parentNode.clientHeight * el.parentNode.clientWidth }, function () {
            resize()
        });
        scope.$watch('data', function () {
            chart.load({ json: scope.data, keys: scope.elementObject.chartOptions.data.keys });
        }, true);
        scope.$watch('elementObject.chartOptions.data.groups', function () {
            generate()
            render();
            resize()
        }, true);
        scope.$watch('elementObject.chartOptions.data.keys.value', function () {
            generate()
            render();
            resize()
        }, true);


        function generate() {
            chart = c3.generate(scope.elementObject.chartOptions);
            //var doc = document;
            //console.log("web worker started: ");
            //callWebWorker({chart: scope.elementObject.chartOptions}).then(function (reply) {
            //    console.log(reply.element);
            // });
        };
        function render() {
            elem.html(chart.element);

        };
        function resize() {
            chart.resize({ height: el.parentNode.clientHeight, width: el.parentNode.clientWidth });
            chart.load({ json: scope.data, keys: scope.elementObject.chartOptions.data.keys });
        }
        function callWebWorker(message) {
            var worker = new Worker('shared-components/chart/worker.js');
            var defer = $q.defer();
            worker.onmessage = function (e) {
                defer.resolve(e.data);
                worker.terminate();
            }

            worker.postMessage(message);
            return defer.promise;
        }

        generate()
        render();
        //resize()
        

    };
});
mapApp.directive('hcChart', function ($q) {
    return {
        restrict: 'E',
        scope: {
            data: "=",
            elementObject: "=element"
        },
        link: function (scope, element) {


            var chartOptions = {
                exporting: {
                    fallbackToExportServer: false
                },
                credits:{enabled: false},
                legend: {
                    layout: 'horizontal',
                    align: 'center',
                    verticalAlign: 'bottom',
                    borderWidth: 0
                },
                result: preProcess(scope.data),
                exporting: {
                    buttons: {
                        contextButton: {
                            menuItems: null,
                            onclick: function () {
                                this.exportChart();
                            }
                        }
                    }
                }
            };

            scope.elementObject.chartOptions = scope.elementObject.chartOptions || chartOptions;

            if (scope.elementObject.chart && scope.elementObject.chart.options) {
                scope.elementObject.chart = Highcharts.chart(element[0], scope.elementObject.chart.options);
            }
            else {
                scope.elementObject.chart = Highcharts.chart(element[0], scope.elementObject.chartOptions);
            }
            
                      
            scope.$watch(function () { return element[0].parentNode.clientHeight * element[0].parentNode.clientWidth }, function () {
                scope.elementObject.chart.setSize(element[0].parentNode.clientWidth, element[0].parentNode.clientHeight);
            });

            scope.$watch('elementObject.chartOptions', function () {
                console.log('options changed');
            }, true);

            scope.$watch('data', function () {
                scope.elementObject.chartOptions.result = preProcess(scope.data);
                console.log('data changed');
            }, true);


            function preProcess(initialArray) {
                if (initialArray && initialArray[0]) {
                    var keys = Object.keys(initialArray[0]);
                    var newArray = [];
                    keys.forEach(function (curKey) {
                        newArray.push({ name: curKey, data: [] });
                    });
                    initialArray.forEach(function (curObject) {
                        keys.forEach(function (curKey, index) {
                            newArray[index].data.push(curObject[curKey]);
                        });
                    });
                    return newArray;
                }
                return [];
            };

            var chartFunctions = {
                removeSeries: function (seriesName) {
                    var seriesIndex = scope.elementObject.chart.options.series.map(function (e) {
                        return e.name;
                    }).indexOf(seriesName);
                    scope.elementObject.chart.series[seriesIndex].remove();
                    
                },
                addSeries: function (seriesObject) {
                    scope.elementObject.chart.addSeries(seriesObject);
                    scope.elementObject.chart.options.series.push(seriesObject);
                    
                },
                updateTitle: function (newTitle) {
                    scope.elementObject.chart.setTitle({ text: newTitle });
                    console.log(scope.elementObject.chart.options);
                }
            };
            scope.elementObject.chartFunctions = chartFunctions;


        }
    };
})
mapApp.directive('columnProperties', function () {

    return {
        templateUrl: 'shared-components/column-properties/columnProperties.html',
        link: link,
        scope: {
            columnObject: "=",
            callFunction: "&"
        }
    };

    function link(scope) {

        scope.partition = function (columnProperty) {
            columnProperty.partition = !columnProperty.partition
            scope.callFunction()
        };
        scope.clicked = function () {
            scope.callFunction()
        }
    };

});
mapApp.directive('dataText', function () {

    return {
        templateUrl: 'shared-components/textBlock/textBlock.html',
        link: link,
        scope: {
            element: "="
        }
    };

    function link(scope) {

        var template = [
            { name: 'title', type: 'string', value: 'Title' },
            { name: 'Show Title', type: 'bool', value: true },
            { name: 'text', type: 'multiline', value: 'Text Area' },
        ];

        scope.element.properties = scope.element.properties || angular.copy(template);

    };
});
metricDashboard.factory('dataManager', function ($resource, $rootScope, $http) {

    var dataScope = $rootScope.$new(true);
    var apiEndPoint = 'http://localhost:49460/api';
    //var apiEndPoint = 'https://pasbadevweb/MAP/api';

    //    DATA OBJECT
    //
    var dataObject = {};

    dataObject.queryValues = {
        table: "Telehealth_360_CAPER",
    }

    //    DATA RESOURCES
    //
    var dataResource = {};

    dataResource.findDataObject = function (DOArray, canvasIndex, groupIndex) {

        var index = -1;
        for (var i = 0; i < DOArray.length; i++) {
            var element = DOArray[i];
            if (element.canvas === canvasIndex && element.dataGroup === groupIndex) { index = i; break; }
        }
        return index;
    };
    dataResource.updateArray = function (sourceArray, targetArray, group) {
        targetArray.length = 0;
        sourceArray.forEach(function (entry) {
            entry = dataResource.checkCalculation(entry, group);
            targetArray.push(entry);
        });
    }
    dataResource.checkCalculation = function (entryObject, group) {
        var calc = group.data.calc;

        if (calc && calc.column1 && entryObject[calc.column1] && calc.column2 && entryObject[calc.column2]) {

            switch (calc.operator) {

                case "+":
                    entryObject[calc.as] = (parseFloat(entryObject[calc.column1] || 0) + parseFloat(entryObject[calc.column2] || 0)).toFixed(2);
                    break;

                case "-":
                    entryObject[calc.as] = (parseFloat(entryObject[calc.column1] || 0) - parseFloat(entryObject[calc.column2] || 0)).toFixed(2);
                    break;

                case "*":
                    entryObject[calc.as] = (parseFloat(entryObject[calc.column1] || 0) * parseFloat(entryObject[calc.column2] || 0)).toFixed(2);
                    break;

                case "/":
                    entryObject[calc.as] = (parseFloat(entryObject[calc.column1] || 0) / parseFloat(entryObject[calc.column2] || 0)).toFixed(2);
                    break;
            }
        }

        return entryObject;
    };

    dataResource.exportToCsv = function(filename, rows) {
        var processRow = function (row) {
            var finalVal = '';
            for (var j = 0; j < row.length; j++) {
                var innerValue = row[j] === null ? '' : row[j].toString();
                if (row[j] instanceof Date) {
                    innerValue = row[j].toLocaleString();
                };
                var result = innerValue.replace(/"/g, '""');
                if (result.search(/("|,|\n)/g) >= 0)
                    result = '"' + result + '"';
                if (j > 0)
                    finalVal += ',';
                finalVal += result;
            }
            return finalVal + '\n';
        };
        var processJSON = function (row) {
            var finalVal = '';
            var keys = Object.keys(row);

            for (var j = 0; j < keys.length; j++) {
                var innerValue = row[keys[j]] === null ? '' : row[keys[j]].toString();
                var result = innerValue.replace(/"/g, '""');
                if (result.search(/("|,|\n)/g) >= 0)
                    result = '"' + result + '"';
                if (j > 0)
                    finalVal += ',';
                finalVal += result;
            }
            return finalVal + '\n';
        }
        var csvFile = '';
        //header
        var headerKeys = Object.keys(rows[0]);
        csvFile += headerKeys.join(",") + '\n';

        for (var i = 0; i < rows.length; i++) {
            //csvFile += processRow(rows[i]);
            csvFile += processJSON(rows[i]);
        }

        var blob = new Blob([csvFile], { type: 'text/csv;charset=utf-8;' });
        if (navigator.msSaveBlob) { // IE 10+
            navigator.msSaveBlob(blob, filename);
        } else {
            var link = document.createElement("a");
            if (link.download !== undefined) { // feature detection
                // Browsers that support HTML5 download attribute
                var url = URL.createObjectURL(blob);
                link.setAttribute("href", url);
                link.setAttribute("download", filename);
                link.style.visibility = 'hidden';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            }
        }
    }

    var userInfoAPI = apiEndPoint + '/appInfo/';
    dataResource.userInfo = function () { return $resource(userInfoAPI); };

    var tableColumnDataAPI = apiEndPoint + '/table/';
    dataResource.tableColumnData = $resource(tableColumnDataAPI + '?table=' + dataObject.queryValues.table);

    var distinctColumnDataAPI = apiEndPoint + '/column/';
    dataResource.testDistinctColumnData = function (columnName, columnType) {
        return $resource(distinctColumnDataAPI + '?table=' + dataObject.queryValues.table + '&colName=' + columnName + '&colType=' + columnType);
    }

    var queryAPI = apiEndPoint + '/query/';
    dataResource.queryData = function (queryObject) {
        var queryString = createQueryString(queryObject);
        return $resource(queryAPI + queryString);
    }

    var reportAPI = apiEndPoint + '/report/';
    dataResource.reports = function (reportObject) {
        var report = createReportPost(reportObject);
        return $http.post(reportAPI, JSON.stringify(report));
    }
    dataResource.getReports = function (type) {
        var queryString = "?reportType=" + type;
        return $resource(reportAPI + queryString);
    };

    var updateReportApi = apiEndPoint + '/update-report/?update=1';
    dataResource.updateReport = function (reportObject) {
        var report = createReportPost(reportObject);
        return $http.post(updateReportApi, JSON.stringify(report));
    }

    var deleteReportAPI = apiEndPoint + '/delete-report/';
    dataResource.deleteReport = function (GUID) {
        return $resource(deleteReportAPI + '?GUID=' + GUID + '&delete=1')
    }
    

    //  DOOOO IT! GET THAT DATAAAA!
    var createQueryString = function (queryObject) {

        var table = "?table=" + queryObject.table;

        var column = "";
        if (queryObject.column.length > 0) {
            column  = "&column=" + queryObject.column.join(",")
        }

        var aggType = "";
        if (queryObject.aggTypes.length > 0) {
            aggType = "&aggType=" + queryObject.aggTypes.join(",")
        }
        
        var group = "";
        if (queryObject.group.length > 0) {
            group = "&group=" + queryObject.group.join(",")
        }

        var partition = "";
        if (queryObject.partition.length > 0) {
            partition = "&partition=" + queryObject.partition.join(",");
        }
        
        var filters = "";
        if (queryObject.filterColumn.length > 0) {
            var filterLength = queryObject.filterColumn.length;
            for (var i = 0; i < filterLength; i++) {
                filters += "&filterColumn=" + queryObject.filterColumn[i] + "&filterValue=" + queryObject.filterValue[i];
            }
        }
        //console.log(table + column + aggType + group + partition + filters);
        return table + column + aggType + group + partition + filters;
       
    }

    var createReportPost = function (reportObject) {
        var retunValue = {};
        retunValue.Report_Name = reportObject.name;
        retunValue.Report_Type = reportObject.roleType;
        retunValue.Report = reportObject;
        retunValue.GUID = reportObject.GUID;
        return retunValue;
    }

    
    //    DATA STRUCTURE
    //
    dataScope.DR = dataResource;
    dataScope.DO = dataObject;


    return dataScope;
});
mapApp.directive('directiveGenerator', ['$compile', function ($compile) {
    return {
        restrict: 'E',
        scope: {
            name: '@',
            attributes: '='
        },
        link: link
    };

    function link(scope, elem, attr) {

        var attributes = '';
        Object.keys(scope.attributes).forEach(function (key, index) {
            attributes = attributes + key + "='" + scope.attributes[key] + "' ";
        });

        elem.replaceWith($compile('<' + scope.name + ' ' + attributes + "></" + scope.name + '>')(scope));
    };
}]);
mapApp.directive('donutChart', ['$timeout', function ($timeout) {
    return {
        scope: { data: "="},
        restrict: 'E',
        link: link
    };

    function link(scope, element) {
        // the D3 bits..
        $timeout(function () {

            //var data = [1, 2, 3, 4];
            var color = d3.scale.category10();
            var el = element[0];
            var pie = d3.layout.pie().sort(null);
            var arc = d3.svg.arc();
            var svg = d3.select(el).append('svg');
            var g = svg.append('g');
            var arcs = g.selectAll('path').data(pie(scope.data)).enter().append('path').style('stroke', 'white').attr('fill', function (d, i) { return color(i) });

            scope.$watch(function () { return el.parentNode.clientHeight * el.parentNode.clientWidth }, function () {

                var width = el.parentNode.clientWidth;
                var height = el.parentNode.clientHeight;
                var min = Math.min(width, height);
                arc.outerRadius(min / 2 * 0.9).innerRadius(min / 2 * 0.45);
                svg.attr({ width: width, height: height });
                g.attr('transform', 'translate(' + width / 2 + ',' + height / 2 + ')');
                arcs.attr('d', arc);
            });


        }, 500);


    }


}]);
mapApp.directive('gaugeChart', ['$timeout', function ($timeout) {
    return {
        scope: { data: "=" },
        restrict: 'E',
        link: link
    };

    function link(scope, element) {
        // the D3 bits..
        //$timeout(function () {
            var el = element[0];
            var chartOptions = {
                bindto: d3.select(el),
                data: {
                    columns: [
                        ['data', 71.4]
                    ],
                    type: 'gauge',
                    onclick: function (d, i) { console.log("onclick", d, i); },
                    onmouseover: function (d, i) { console.log("onmouseover", d, i); },
                    onmouseout: function (d, i) { console.log("onmouseout", d, i); }
                },
                color: {
                    pattern: ['#FF0000', '#F97600', '#F6C600', '#60B044'],
                    threshold: {
                        values: [30, 60, 90, 100]
                    }
                }
            };
            var chart = c3.generate(chartOptions);

            scope.$watch(function () { return el.parentNode.clientHeight * el.parentNode.clientWidth }, function () {
                chart.resize({ height: el.parentNode.clientHeight, width: el.parentNode.clientWidth });
            });




        //}, 1);


    }


}]);
mapApp.directive('header', function () {
	    return {
	        templateUrl: 'shared-components/header/header.html',
	        restrict: 'E',
	        replace: true
	    }
});

mapApp.directive('listControll', function () {

    return {
        restrict: 'EA',
        replace: true,
        templateUrl: 'shared-components/list-controll/list-controll.html',
        scope: {
            list: "=",
            out: "=",
            selectable: "=",
            callFunction: "&"
        },
        link: link
    }

    function link(scope, elem) {

        scope.$watch('list', function (newVal) {
            if (newVal) {
                scope.key = Object.keys(scope.list[0])[0];
            }            
        }, true);

        scope.isSelected = function (key, value) {
            
            var selectedValues = scope.out.map(function (obj) {
                return obj[key];
            })

            if (selectedValues.indexOf(value) > -1) {
                return true;
            }
            return false;
        };

    }

});
//list-controll directive
metricDashboard.controller('MetricDashboardCanvas', ['$scope', 'appStateManager', 'componentModifier', '$rootScope', 'dataManager', function ($scope, appStateManager, componentModifier, $rootScope, dataManager) {

    
    $scope.component = componentModifier;
    $scope.canvases = appStateManager.DSD.product.canvases;
    $scope.dashboard = appStateManager.DSD.product.dashboard;
    $scope.reports = appStateManager.DSD.product.reports;
    var product = appStateManager.DSD.product;
    $scope.index = product.dashboard.index;
     
    
    $scope.tabSelected = function (index) {
        $scope.dashboard.index.canvas = index;
    };

    $scope.backgroundPreview = false;

    $scope.gridsterOpts = {
        columns: 36,
        margins: [10,10],
        minRows: 3,
        resizable: {
            enabled: true,
            handles: ['n', 'e', 's', 'w', 'se', 'sw', 'nw']
        }
    }

    $scope.gridsterReportOpts = {
        columns: 36,
        margins: [10,10],
        minRows: 3,
        resizable: {
            enabled: false
        },
        draggable: {
            enabled: false
        }
    }

    $scope.addElement = function (index) {
        var element = {};
        element.name = 'New ' + componentModifier.elementTypes[index];
        element.type = componentModifier.elementTypes[index];
        componentModifier.addElement(element, $scope.index);
    };

    $scope.updateData = function(){
        console.log("data should update");
    };

}]);
metricDashboard.controller('ComponentModal', ['$scope', '$uibModalInstance', 'appStateManager', 'componentModifier', 'dataManager', function ($scope, $uibModalInstance, appStateManager, componentModifier, dataManager) {


    $scope.component = componentModifier;
    var OT = appStateManager.OT;
    var product = appStateManager.DSD.product;
    $scope.index = product.dashboard.index;
    $scope.canvases = product.canvases;
    $scope.DO = dataManager.DO;
    var DR = dataManager.DR;


    //    CANVASES
    //
    $scope.newCanvasName = { name: '' };
    $scope.filterCanvasSelection = function () {
        if ($scope.canvases[$scope.index.canvas]) {
            return "Canvas: " + $scope.canvases[$scope.index.canvas].name;
        }
        return "Select Canvas";
    }
    $scope.canvasSelected = function (index) {
        $scope.index.canvas = index;
    };


    //    DATA GROUPS
    //
    $scope.newGroupName = { name: '' };
    $scope.filterDataGroupSelection = function () {
        if ($scope.canvases[$scope.index.canvas] && $scope.canvases[$scope.index.canvas].dataGroups[$scope.index.group]) {
            return "Data Group: " + $scope.canvases[$scope.index.canvas].dataGroups[$scope.index.group].name;
        }
        return "Select Data Group";
    }
    $scope.groupSelected = function (index) {
        $scope.index.group = index;
    };


    //    RETURN VALUES
    //
    $scope.availableValueIndex = -1;
    $scope.availableValueSelected = function (index) {
        $scope.availableValueIndex = index;
    };
    $scope.currentValueIndex = -1;
    $scope.currentValueSelected = function (index) {
        $scope.currentValueIndex = index;
    };
    $scope.addValueToReturn = function () {
        var columnProperty = angular.copy(OT.columnProperty);
        columnProperty.column = $scope.canvases[$scope.index.canvas].dataGroups[$scope.index.group].data.tableColumns[$scope.availableValueIndex].COLUMN_NAME;
        $scope.canvases[$scope.index.canvas].dataGroups[$scope.index.group].data.columnProperties.push(columnProperty);
    };
    $scope.removeValueFromReturn = function () {
        $scope.canvases[$scope.index.canvas].dataGroups[$scope.index.group].data.columnProperties.splice($scope.currentValueIndex, 1);
    }


    //    FILTERS
    //
    $scope.newFilterName = { name: '' };
    $scope.filterSelected = function (index) {
        $scope.index.filter = index;
    };

    $scope.availableColumnIndex = -1;
    $scope.availableColumnSelected = function (index) {
        $scope.availableColumnIndex = index;
        //new
        $scope.newFilterName.name = $scope.canvases[$scope.index.canvas].dataGroups[$scope.index.group].data.tableColumns[index].COLUMN_NAME
    };
    $scope.currentColumnIndex = -1;
    $scope.currentColumnSelected = function (index) {
        $scope.currentColumnIndex = index;
    };

    $scope.tempNewFilterColumns = [];
    $scope.addColumnToFilter = function () {
        $scope.tempNewFilterColumns.push($scope.canvases[$scope.index.canvas].dataGroups[$scope.index.group].data.tableColumns[$scope.availableColumnIndex]);
        $scope.newFilterName.name = $scope.canvases[$scope.index.canvas].dataGroups[$scope.index.group].data.tableColumns[$scope.availableColumnIndex].COLUMN_NAME
    };
    $scope.removeColumnFromFilter = function () {
        $scope.tempNewFilterColumns.splice($scope.currentColumnIndex, 1);      
    }
    $scope.addFilter = function () {
        $scope.component.addFilter($scope.newFilterName, $scope.index, $scope.canvases[$scope.index.canvas].dataGroups[$scope.index.group].data.tableColumns[$scope.availableColumnIndex]);
        $scope.tempNewFilterColumns.length = 0;
    };


    //    ELEMENTS
    //
    $scope.element = {
        name: '',
        width: 3,
        height: 3,
        type: 'Select Element Type'
    };
    $scope.elementIndexValue = -1;

    $scope.elementTypeSelected = function (type) {
        $scope.element.type = type;
    };
    $scope.elementSelected = function (index) {
        $scope.index.element = index;
    };


    //    MODAL CONTROLLS
    //
    $scope.ok = function () {
        $uibModalInstance.close();
    };

    $scope.cancel = function () {
        $uibModalInstance.dismiss('cancel');
    };



}]);
metricDashboard.controller('MetricDashboard', ['$scope', 'appStateManager', 'tempService', '$rootScope', '$state', 'componentModifier', '$uibModal', 'dataManager', function ($scope, appStateManager, tempService, $rootScope, $state, componentModifier, $uibModal, dataManager) {


    var D = appStateManager.D;
    var DSD = appStateManager.DSD;
    var DOF = appStateManager.DOF;
    var DR = dataManager.DR;
    var DO = dataManager.DO;

    var currentProduct = DOF.getProductLine();
    DSD.product = D[currentProduct];
    DO.product = DO[currentProduct];

    $scope.reports = DSD.product.reports;
    $scope.canvases = DSD.product.canvases;
    $scope.dashboard = DSD.product.dashboard;
    $scope.DSD = DSD;
    $scope.DOF = DOF;
    $scope.D = D;

    $scope.products = tempService.products;
    $scope.component = componentModifier;

    //initial controller load, mode check:
    //if (DSD.product.dashboard.mode === 'Analysis') {
    //    $scope.goRoute('metricDashboard');
    //}

    $scope.openReportModal = function (size) {

        var modalInstance = $uibModal.open({
            animation: true,
            templateUrl: 'core-components/metric-dashboard/templates/report-modal.html',
            controller: 'ReportModal',
            size: size
        });
    }
    $scope.editReportModal = function (size) {

        var modalInstance = $uibModal.open({
            animation: true,
            templateUrl: 'core-components/metric-dashboard/templates/edit-report-modal.html',
            controller: 'EditReportModal',
            size: size
        });
    }
    $scope.boolShow = function (bool) { if (bool) { return 'Show'; } return 'Hide'; };

    $scope.goRoute = function (routeName) {
        $state.go(routeName);
    };

    $scope.passProduct = function (product) {

        DOF.setProductLine(product.dataName);
        D[product.dataName].name = D[product.dataName].name || product.name;
        D[product.dataName].dataTest = D[product.dataName].dataTest || { text: "Text for " + product.name };
        DSD.product = D[product.dataName];
        DO.product = DO[product.dataName];
    };

    //Listen for gridster change
    //$rootScope.$on('gridster-draggable-changed', function (gridster) {
    //    var evt = window.document.createEvent('UIEvents');
    //    evt.initUIEvent('resize', true, false, window, 0);
    //    window.dispatchEvent(evt);
    //})
    
    $scope.testDataDownload = function () {
        var resultdata = '';
        var nametemp = '';

        if ($scope.dashboard.mode === 'Analysis') {
            var resultdata = $scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group].data.result;
            var name = $scope.canvases[$scope.dashboard.index.canvas].name;
        }
        else if ($scope.dashboard.mode === 'Reporting'){
            var resultdata = $scope.reports[$scope.dashboard.index.report].dataGroups[$scope.dashboard.index.group].data.result;
            var name = $scope.reports[$scope.dashboard.index.report].name;
        }

        name = "MAP_" + name.split(' ').join('_') + '_Data.csv';

        console.log(resultdata);
        DR.exportToCsv(name, resultdata);
    }

}]);
metricDashboard.controller('EditReportModal', ['$scope', 'appStateManager', 'dataManager', '$uibModalInstance', function ($scope, appStateManager, dataManager, $uibModalInstance) {

    var DR = dataManager.DR;
    var DSD = appStateManager.DSD;
    var D = appStateManager.D;
    var DOF = appStateManager.DOF;
    $scope.DSD = appStateManager.DSD;
    $scope.D = appStateManager.D;
    $scope.canvases = appStateManager.DSD.product.canvases;
    $scope.dashboard = appStateManager.DSD.product.dashboard;
    $scope.reports = appStateManager.DSD.product.reports;
    $scope.userReports = appStateManager.DSD.product.userReports;
    $scope.confirm = false;
    $scope.confirmUser = false;

    DR.getReports('Admin').get().$promise.then(function (resp) {
        DSD.product.reports.length = 0;

        resp.model.forEach(function (item, index) {
            DSD.product.reports.push(JSON.parse(item.JSON_Value));
        })
    }).catch(function (e) { console.log(e); });

    DR.getReports('User').get().$promise.then(function (resp) {
        DSD.product.userReports.length = 0;

        resp.model.forEach(function (item, index) {
            DSD.product.userReports.push(JSON.parse(item.JSON_Value));
        })
    }).catch(function (e) { console.log(e); });

    $scope.pushReportEdit = function () {
        
        $scope.canvases.push($scope.reports[$scope.dashboard.index.report]);

        var newCanvas = $scope.canvases[$scope.canvases.length - 1];
        newCanvas.overwrite = true;
        if (newCanvas.roleType === 'Admin' && D.role !== 0) {
            newCanvas.roleType = 'User';
            newCanvas.overwrite = false;
            newCanvas.fromDB = true;
        }


        $scope.ok();
    };
    $scope.pushUserReportEdit = function () {

        $scope.canvases.push($scope.userReports[$scope.dashboard.index.userReport]);

        var newCanvas = $scope.canvases[$scope.canvases.length - 1];
        newCanvas.overwrite = true;
        if (newCanvas.roleType === 'Admin' && D.role !== 0) {
            newCanvas.roleType = 'User';
            newCanvas.overwrite = false;
            newCanvas.fromDB = true;
        }

        $scope.ok();
    };

    $scope.deleteReport = function () {
        var GUID = DSD.product.reports[$scope.dashboard.index.report].GUID;
        DR.deleteReport(GUID).get().$promise.then(function () {
            $scope.ok();
            $scope.confirm = false;
        }).catch(function (e) {
            console.log(e);
            $scope.ok();
            $scope.confirm = false;
        });
    }
    $scope.deleteUserReport = function () {
        var GUID = DSD.product.userReports[$scope.dashboard.index.userReport].GUID;
        DR.deleteReport(GUID).get().$promise.then(function () {
            $scope.ok();
            $scope.confirm = false;
        }).catch(function (e) {
            console.log(e);
            $scope.ok();
            $scope.confirm = false;
        });
    }

    $scope.ok = function () {
        $uibModalInstance.close();
    };




}]);
metricDashboard.controller('MetricDashboardLeft', ['$scope', 'appStateManager', 'dataManager', '$timeout', function ($scope, appStateManager, dataManager, $timeout) {

    var product = appStateManager.DSD.product;
    var DR = dataManager.DR;
    var DO = dataManager.DO;
    var toggle = 0;

    $scope.index = product.dashboard.index;
    $scope.dataGroups = product.canvases[$scope.index.canvas].dataGroups;

    $scope.canvases = appStateManager.DSD.product.canvases;
    $scope.dashboard = appStateManager.DSD.product.dashboard;

    $scope.groupSelected = function (index) {

        $scope.index.group = index;
    };

    $scope.filterClick = function () {

        $timeout(function () {

            var group = $scope.canvases[$scope.index.canvas].dataGroups[$scope.index.group];

            group.data.query.filterColumn.length = 0;
            group.data.query.filterValue.length = 0;

            var filterLength = group.filters.length;
            for (var i = 0; i < filterLength; i++) {

                var filterColumn = Object.keys(group.filters[i].values[0])[0];

                var filterValues = group.filters[i].selectedValues.map(function (obj) {
                    return obj[filterColumn];
                });

                if (filterValues.length > 0) {
                    group.data.query.filterColumn.push(filterColumn);
                    group.data.query.filterValue.push(filterValues.join(","));
                }

            }

            DR.queryData(group.data.query).get().$promise.then(function (resp) {
                console.log(resp.model);
                DR.updateArray(resp.model, group.data.result, group);
            }).catch(function () { group.data.result.length = 0; });

        }, 1);
    };

    $scope.toggleClearSelect = function (index) {

        var filter = $scope.canvases[$scope.index.canvas].dataGroups[$scope.index.group].filters[index];

        filter.selectToggle = filter.selectToggle || 0;
        if (filter.selectToggle === 0) {

            filter.values.forEach(function (entry) {
                filter.selectedValues.push(entry);
            });
            filter.selectToggle++;
        }
        else if (filter.selectToggle === 1) {

            filter.selectedValues.length = 0;
            filter.selectToggle--;
        }
        $scope.filterClick();

    };

}]);
metricDashboard.controller('MetricDashboardReportLeft', ['$scope', 'appStateManager', 'dataManager', '$timeout', function ($scope, appStateManager, dataManager, $timeout) {

    var DR = dataManager.DR;
    var DSD = appStateManager.DSD;
    $scope.index = appStateManager.DSD.product.dashboard.index;
    $scope.reports = appStateManager.DSD.product.reports;
    $scope.dashboard = appStateManager.DSD.product.dashboard;


    DR.getReports('Admin').get().$promise.then(function (resp) {
        DSD.product.reports.length = 0;

        resp.model.forEach(function (item, index) {
            DSD.product.reports.push(JSON.parse(item.JSON_Value));
        })
    });

    $scope.groupSelected = function (index) {
        $scope.index.group = index;
    };

    $scope.showGroups = function () {
        var report = $scope.reports[$scope.index.report]
        if (report && report.dataGroups && report.dataGroups.length > 1) {
            return true;
        }
        return false;
    }

    $scope.filterClick = function () {

        $timeout(function () {
            var group = $scope.reports[$scope.index.report].dataGroups[$scope.index.group];

            group.data.query.filterColumn.length = 0;
            group.data.query.filterValue.length = 0;

            var filterLength = group.filters.length;
            for (var i = 0; i < filterLength; i++) {

                var filterColumn = Object.keys(group.filters[i].values[0])[0];

                var filterValues = group.filters[i].selectedValues.map(function (obj) {
                    return obj[filterColumn];
                });

                if (filterValues.length > 0) {
                    group.data.query.filterColumn.push(filterColumn);
                    group.data.query.filterValue.push(filterValues.join(","));
                }

            }

            DR.queryData(group.data.query).get().$promise.then(function (resp) {
                DR.updateArray(resp.model, group.data.result, group);
            });

        }, 1);
    };

    $scope.toggleClearSelect = function (index) {

        var filter = $scope.reports[$scope.index.report].dataGroups[$scope.index.group].filters[index];

        filter.selectToggle = filter.selectToggle || 0;
        if (filter.selectToggle === 0) {

            filter.values.forEach(function (entry) {
                filter.selectedValues.push(entry);
            });
            filter.selectToggle++;
        }
        else if (filter.selectToggle === 1) {

            filter.selectedValues.length = 0;
            filter.selectToggle--;
        }
        $scope.filterClick();

    };

}]);
metricDashboard.controller('ReportModal', ['$scope', 'appStateManager', 'dataManager', '$uibModalInstance', function ($scope, appStateManager, dataManager, $uibModalInstance) {

    var DR = dataManager.DR;
    var DSD = appStateManager.DSD;
    var D = appStateManager.D;
    var DOF = appStateManager.DOF;
    $scope.DSD = appStateManager.DSD;
    $scope.canvases = appStateManager.DSD.product.canvases;
    $scope.dashboard = appStateManager.DSD.product.dashboard;

    $scope.ok = function () {
        $uibModalInstance.close();
    };


    if (D.role === 0) {
        $scope.ReportTypes = ['User', 'Admin'];
    }
    else {
        $scope.ReportTypes = ['User'];
    }
    

    $scope.boolShow = function (bool) { if (bool) { return 'Show'; } return 'Hide'; };
    $scope.pushReportCopy = function () {

        if (DSD.product.canvases[$scope.dashboard.index.canvas].fromDB === true) {
            DSD.product.canvases[$scope.dashboard.index.canvas].GUID = DOF.generateGUID();
        }

        DR.reports(DSD.product.canvases[$scope.dashboard.index.canvas]).then(function (resp)
        {

            //toastr.success('Report Created');
            $scope.ok();
            DSD.product.canvases[$scope.dashboard.index.canvas].overwrite = true;
            DSD.product.canvases[$scope.dashboard.index.canvas].fromDB = true;
            
        }).catch(function (e) { console.log(e); });
       
    };

    $scope.pushUpdatedReport = function () {
        DR.updateReport(DSD.product.canvases[$scope.dashboard.index.canvas]).then(function (resp) {
            $scope.ok();
        }).catch(function (e) { console.log(e); });
    }

}]);
metricDashboard.controller('ReturnColumnController', ['$scope', 'appStateManager', '$uibModalInstance', function ($scope, appStateManager, $uibModalInstance) {

    var OT = appStateManager.OT;
    $scope.DSD = appStateManager.DSD;
    $scope.canvases = appStateManager.DSD.product.canvases;
    $scope.dashboard = appStateManager.DSD.product.dashboard;

    $scope.ok = function () {
        $uibModalInstance.close();
    };

    $scope.availableColumnIndex = -1;
    $scope.availableColumnSelected = function (index) {
        $scope.availableColumnIndex = index;
    };
    $scope.currentColumnIndex = -1;
    $scope.currentColumnSelected = function (index) {
        $scope.currentColumnIndex = index;
    };
    $scope.addColumnToFilter = function () {
        var columnProperty = angular.copy(OT.columnProperty);
        columnProperty.column = $scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group].data.tableColumns[$scope.availableColumnIndex].COLUMN_NAME;
        $scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group].data.columnProperties.push(columnProperty);
    };
    $scope.removeColumnFromFilter = function () {
        $scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group].data.columnProperties.splice($scope.currentColumnIndex, 1);
    }

}]);
metricDashboard.controller('MetricDashboardRight', ['$scope', 'appStateManager','dataManager', '$uibModal', function ($scope, appStateManager,dataManager, $uibModal) {

    var DR = dataManager.DR;
    $scope.DSD = appStateManager.DSD;
    $scope.canvases = appStateManager.DSD.product.canvases;
    $scope.dashboard = appStateManager.DSD.product.dashboard;

    $scope.showAdvanced = function () {
        $scope.advanced = !$scope.advanced;
        console.log($scope.advanced);
    };
    $scope.advanced = false;

    var currentElement = function () {
        return $scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group].elements[$scope.dashboard.index.element];
    };

    $scope.boolGrouped = function (bool) { if (bool) { return 'Grouped'; } return 'Not Grouped'; };


    $scope.openReturnModal = function (size) {

        var modalInstance = $uibModal.open({
            animation: true,
            templateUrl: 'core-components/metric-dashboard/templates/return-column-modal.html',
            controller: 'ReturnColumnController',
            size: size
        });
    }

    $scope.propertyClick = function () {

        var groupData = $scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group].data;
        var group = $scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group];
        
        groupData.query.column.length = 0;
        groupData.query.partition.length = 0;
        groupData.query.aggTypes.length = 0;
        groupData.query.group.length = 0;

        var length = groupData.columnProperties.length;

        for (var i = 0; i < length; i++)
        {
            groupData.query.column.push(groupData.columnProperties[i].column);
            groupData.query.aggTypes.push(groupData.columnProperties[i].aggregate);
            if (groupData.columnProperties[i].partition === true) {
                groupData.query.partition.push(groupData.columnProperties[i].column);
            }
            if (groupData.columnProperties[i].grouped === true) {
                groupData.query.group.push(groupData.columnProperties[i].column);
            }

        }

        DR.queryData(groupData.query).get().$promise.then(function (resp) {
            DR.updateArray(resp.model, groupData.result, group);
        }).catch(function () { groupData.result.length = 0; });
    }


    $scope.sendPost = function () {
        DR.reports();
    };
    
}]);
mapApp.directive('headerNotification', function () {
	    return {
	        templateUrl: 'core-components/metric-dashboard/directives/header-menu.html',
	        restrict: 'E',
	        replace: true,
	    }
});
metricDashboard.factory('componentModifier', function (appStateManager, $uibModal, dataManager) {

    var DSD = appStateManager.DSD;
    var OT = appStateManager.OT;
    var DOF = appStateManager.DOF;
    var DR = dataManager.DR;
    var DO = dataManager.DO;
    var modifier = {};

    modifier.elementTypes = ['title-block', 'text-block', 'chart-element', 'hc-chart', 'data-text','spacer']; // 'donut-chart', 'gauge-chart'


    //    CANVASES
    //
    modifier.addCanvas = function () {
        var newCanvas = angular.copy(OT.Canvas);
        newCanvas.GUID = DOF.generateGUID();
        DSD.product.canvases.push(newCanvas);
    };
    modifier.addCanvasByName = function (canvasObject) {
        var newCanvas = angular.copy(OT.Canvas);
        newCanvas.name = canvasObject.name;
        newCanvas.GUID = DOF.generateGUID();
        DSD.product.canvases.push(newCanvas);
        canvasObject.name = null;
    };
    modifier.deleteCanvas = function (indexObject) {
        DSD.product.canvases.splice(indexObject.canvas, 1);
    };


    //    DATA GROUPS
    //
    modifier.addGroup = function (groupObject, indexObject) {

        var newGroup = angular.copy(OT.Group);
        newGroup.name = groupObject.name;
        DSD.product.canvases[indexObject.canvas].dataGroups.push(newGroup);
        indexObject.group = DSD.product.canvases[indexObject.canvas].dataGroups.length - 1;
        groupObject.name = null;

        DR.tableColumnData.get().$promise.then(function (resp) {

            //DR.updateData(DO.product.dataQueries, resp, indexObject.canvas, DSD.product.canvases[indexObject.canvas].dataGroups.length - 1);
            DR.updateArray(resp.model, DSD.product.canvases[indexObject.canvas].dataGroups[indexObject.group].data.tableColumns, DSD.product.canvases[indexObject.canvas].dataGroups[indexObject.group]);
        });
    };
    modifier.deleteGroup = function (indexObject) {

        DSD.product.canvases[indexObject.canvas].dataGroups.splice(indexObject.group, 1);
    };


    //    FILTERS
    //
    modifier.addFilter = function (filterObject, indexObject, columnObject) {

        var newFilter = angular.copy(OT.Filter);
        newFilter.name = filterObject.name;
        DSD.product.canvases[indexObject.canvas].dataGroups[indexObject.group].filters.push(newFilter);
        filterObject.name = null;

        DR.testDistinctColumnData(columnObject.COLUMN_NAME, columnObject.DATA_TYPE).get().$promise.then(function (resp) {
            DSD.product.canvases[indexObject.canvas].dataGroups[indexObject.group].filters[DSD.product.canvases[indexObject.canvas].dataGroups[indexObject.group].filters.length - 1].values = resp.model;
            //console.log(resp.model);
            return true;
        });
    };
    modifier.deleteFilter = function (indexObject) {

        DSD.product.canvases[indexObject.canvas].dataGroups[indexObject.group].filters.splice(indexObject.filter, 1);
    };


    //    ELEMENTS
    //
    modifier.addElement = function (elementObject, indexObject) {

        var newElement = angular.copy(OT.Element);
        newElement.name = elementObject.name;
        newElement.type = elementObject.type;
        newElement.width = parseInt(elementObject.width) || 8;
        newElement.height = parseInt(elementObject.height) || 5;

        DSD.product.canvases[indexObject.canvas].dataGroups[indexObject.group].elements.push(newElement);
        elementObject.name = null;
    };
    modifier.deleteElement = function (indexObject) {

        DSD.product.canvases[indexObject.canvas].dataGroups[indexObject.group].elements.splice(indexObject.element, 1);
    };


    //    MODAL
    //
    modifier.openModal = function (size) {

        var modalInstance = $uibModal.open({
            animation: true,
            templateUrl: 'core-components/metric-dashboard/templates/component-modal.html',
            controller: 'ComponentModal',
            size: size
        });
    };



    return modifier;

});
mapApp.service('tempService', function () {

    this.products = [       
        { name: 'TeleHealth', dataName: 'teleHealth', icon: 'th', linkValue: 'metric-dashboard/reporting', iconColorClass: 'colorMed' }
    ];
    this.future = [
    //{ name: 'Behavioral Health', dataName: 'behavioralHealth', icon: 'bh360', linkValue: 'metric-dashboard', iconColorClass: 'colorMed' },
    { name: 'Public Health', dataName: 'publicHealth', icon: 'ph360', linkValue: 'metric-dashboard', iconColorClass: 'colorMed' },
    //{ name: 'Access To Care', dataName: 'accessToCare', icon: 'caduceus1', linkValue: 'metric-dashboard', iconColorClass: 'color4' },
    //{ name: 'Beneficiary Health', dataName: 'beneficiaryHealth', icon: 'family21', linkValue: 'metric-dashboard', iconColorClass: 'color5' },
    { name: 'Coding', dataName: 'coding', icon: 'numbered10', linkValue: 'metric-dashboard', iconColorClass: 'color1' },
    //{ name: 'Data Processing', dataName: 'dataProcessing', icon: 'monitor7', linkValue: 'metric-dashboard', iconColorClass: 'color5' },
    { name: 'Data Quality', dataName: 'dataQuality', icon: 'positive3', linkValue: 'metric-dashboard', iconColorClass: 'color2' },
    //{ name: 'Performance', dataName: 'performance', icon: 'ascendant6', linkValue: 'metric-dashboard', iconColorClass: 'color4' },
    //{ name: 'Utilization', dataName: 'utilization', icon: 'circle54', linkValue: 'metric-dashboard', iconColorClass: 'color3' },
	{ name: 'CHUP', dataName: 'chup', icon: 'ascendant6', linkValue: 'metric-dashboard', iconColorClass: 'color3' },
	{ name: 'PAWS', dataName: 'paws', icon: 'circle54', linkValue: 'metric-dashboard', iconColorClass: 'color4' },
    ];

    this.titles = [
        { title: 'Metric Reports', description: 'View your data on our state-of-the-art platform' },
        { title: 'File Sharing', description: 'Publish and share files on the Bulletin Board' },
        { title: 'Custom Insight', description: 'Create custom dashboard views with your data' }
    ]

});

mapApp.directive("selectable", function () {
    return function (scope, element, attr) {
        var options = scope.$eval(attr.selectableOptions) || {};

        if (attr.selectableList && attr.selectableOut) {
            element.bind("selectablestop", function () {
                var selectableList = scope.$eval(attr.selectableList),
                    selectableOut = scope.$eval(attr.selectableOut), s;
                var selected = !selectableList ? [] : element.find('.ui-selected').map(function () {
                    return selectableList[$(this).index()];
                }).get();
                scope.$apply(function () {
                    selectableOut.splice(0);
                    while (s = selected.shift())
                        selectableOut.push(s);
                });
            });
        }

        scope.$watch(attr.selectable, function (value, old) {
            if (value || value === undefined)
                return element.selectable(options);
            if (!value && old) {
                element.selectable("destroy");
                element.find('.ui-selected').removeClass('ui-selected');
                if (attr.selectableOut) {
                    scope[attr.selectableOut] = [];
                }
            }
        })
    }
})
.directive("selectableEvents", ['$parse', function ($parse) {
    return function (scope, element, attr) {
        var selectableEvents = scope.$eval(attr.selectableEvents) || {};

        $.map(selectableEvents, function (callback, eventName) {
            element.bind("selectable" + eventName, function (e, ui) {
                if (e.preventDefault) e.preventDefault();

                var selectableList = scope.$eval(attr.selectableList);
                var selected = !selectableList ? [] : element.find('.ui-selected').map(function () {
                    return selectableList[$(this).index()];
                }).get();

                var fn = $parse(callback);
                scope.$apply(function () {
                    fn(scope, {
                        $ui: ui,
                        $event: e,
                        $list: scope.$eval(attr.selectableList),
                        $selected: selected
                    });
                });
            });
        });
    }
}]);
platformHome.controller('PlatformHome', ['$scope', '$state', 'tempService', 'appStateManager', 'dataManager', function ($scope, $state, tempService, appStateManager, dataManager) {

    $scope.products = tempService.products;
    $scope.titles = tempService.titles;
    $scope.future = tempService.future;

    //var data = appStateManager;
    var D = appStateManager.D;
    var DOF = appStateManager.DOF;
    var DR = dataManager.DR;

    $scope.passProduct = function (product) {

        DR.userInfo().get().$promise.then(function (resp) {

            if (resp.RoleInfo && resp.RoleInfo[0].roleName) {
                if (resp.RoleInfo[0].roleName === 'Report Admin') {
                    D.role = 0;
                }
                else if (resp.RoleInfo[0].roleName === 'Report Builder') {
                    D.role = 1;
                }
            }

            DOF.setProductLine(product);

            if (D[product.dataName]) {
                if (D[product.dataName].dashboard.mode === 'Analysis') {
                    goRoute('metricDashboard');
                }
                else {
                    goRoute('metricDashboardReporting');
                }
            }
            else {
                console.log("error loading service line");
            }

        }).catch(function (error) {
            console.log("Error collecting user data");
            console.log(error);
            DOF.setProductLine(product);

            if (D[product.dataName]) {
                if (D[product.dataName].dashboard.mode === 'Analysis') {
                    goRoute('metricDashboard');
                }
                else {
                    goRoute('metricDashboardReporting');
                }
            }
            else {
                console.log("error loading service line");
            }
        });

    };

    var goRoute = function (routeName) {
        $state.go(routeName);
    };

}]);
mapApp.directive('property', ['$compile', function ($compile) {
    return {
        restrict: 'E',
        scope: {
            propertyObject: "="
        },
        link: link
    };

    function link(scope, elem, attr) {

        var compileString = '';

        switch (scope.propertyObject.type) {
            case 'string':               
                compileString = '<input type="text" class="form-control" style="border-radius:0;" ng-model="propertyObject.value" />';
                break;

            case 'bool':
                compileString = '<toggle-switch bool-object="propertyObject"></toggle-switch>';
                break;

            case 'multiline':
                compileString = '<textarea rows="20" class="form-control" ng-model="propertyObject.value"></textarea>';
                break;
        }

        elem.replaceWith($compile(compileString)(scope));

    }

}]);
mapApp.directive('textBlock', function () {

    return {
        templateUrl: 'shared-components/textBlock/textBlock.html',
        link: link,
        scope: {
            element: "="
        }
    };

    function link(scope) {

        var template = [
            { name: 'title', type: 'string', value: 'Title' },            
            { name: 'Show Title', type: 'bool', value: true },
            { name: 'text', type: 'multiline', value: 'Text Area' },
        ];

        scope.element.properties = scope.element.properties || angular.copy(template);

    };
});
mapApp.directive('titleBlock', function () {

    return {
        templateUrl: 'shared-components/titleBlock/titleBlock.html',
        link: link,
        scope: {
            element: "="
        }
    };

    function link(scope) {

        var template = [
            { name: 'title', type: 'string', value: 'Title' },
            { name: 'subtitle', type: 'string', value: 'Subtitle' },
            { name: 'Show Subtitle', type: 'bool', value: true }
        ];

        scope.element.properties = scope.element.properties || angular.copy(template);

    };
});
mapApp.directive('toggleSwitch', function () {

    return {
        templateUrl: 'shared-components/toggleSwitch/toggleSwitch.html',
        replace: true,
        link: link,
        scope: {
            boolObject: "="
        }
    };

    function link(scope) {

    };
});