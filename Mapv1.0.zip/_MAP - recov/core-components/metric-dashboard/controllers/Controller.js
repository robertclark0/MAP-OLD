﻿metricDashboard.controller('MetricDashboard', ['$scope', 'appStateManager', 'tempService', '$rootScope', '$state', 'componentModifier', '$uibModal', 'dataManager', function ($scope, appStateManager, tempService, $rootScope, $state, componentModifier, $uibModal, dataManager) {


    var D = appStateManager.D;
    var DSD = appStateManager.DSD;
    var DOF = appStateManager.DOF;
    var DR = dataManager.DR;
    var DO = dataManager.DO;

    var currentProduct = DOF.getProductLine();
    DSD.product = D[currentProduct];
    DO.product = DO[currentProduct];

    $scope.reports = DSD.product.reports;
    $scope.canvases = DSD.product.canvases;
    $scope.dashboard = DSD.product.dashboard;
    $scope.DSD = DSD;
    $scope.DOF = DOF;
    $scope.D = D;

    $scope.products = tempService.products;
    $scope.component = componentModifier;

    //initial controller load, mode check:
    //if (DSD.product.dashboard.mode === 'Analysis') {
    //    $scope.goRoute('metricDashboard');
    //}

    $scope.openReportModal = function (size) {

        var modalInstance = $uibModal.open({
            animation: true,
            templateUrl: 'core-components/metric-dashboard/templates/report-modal.html',
            controller: 'ReportModal',
            size: size
        });
    }
    $scope.editReportModal = function (size) {

        var modalInstance = $uibModal.open({
            animation: true,
            templateUrl: 'core-components/metric-dashboard/templates/edit-report-modal.html',
            controller: 'EditReportModal',
            size: size
        });
    }
    $scope.boolShow = function (bool) { if (bool) { return 'Show'; } return 'Hide'; };

    $scope.goRoute = function (routeName) {
        $state.go(routeName);
    };

    $scope.passProduct = function (product) {

        DOF.setProductLine(product.dataName);
        D[product.dataName].name = D[product.dataName].name || product.name;
        D[product.dataName].dataTest = D[product.dataName].dataTest || { text: "Text for " + product.name };
        DSD.product = D[product.dataName];
        DO.product = DO[product.dataName];
    };

    //Listen for gridster change
    //$rootScope.$on('gridster-draggable-changed', function (gridster) {
    //    var evt = window.document.createEvent('UIEvents');
    //    evt.initUIEvent('resize', true, false, window, 0);
    //    window.dispatchEvent(evt);
    //})
    
    $scope.testDataDownload = function () {
        var resultdata = '';
        var nametemp = '';

        if ($scope.dashboard.mode === 'Analysis') {
            var resultdata = $scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group].data.result;
            var name = $scope.canvases[$scope.dashboard.index.canvas].name;
        }
        else if ($scope.dashboard.mode === 'Reporting'){
            var resultdata = $scope.reports[$scope.dashboard.index.report].dataGroups[$scope.dashboard.index.group].data.result;
            var name = $scope.reports[$scope.dashboard.index.report].name;
        }

        name = "MAP_" + name.split(' ').join('_') + '_Data.csv';

        console.log(resultdata);
        DR.exportToCsv(name, resultdata);
    }

}]);