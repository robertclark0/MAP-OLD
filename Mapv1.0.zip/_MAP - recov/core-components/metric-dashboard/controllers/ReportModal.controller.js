﻿metricDashboard.controller('ReportModal', ['$scope', 'appStateManager', 'dataManager', '$uibModalInstance', function ($scope, appStateManager, dataManager, $uibModalInstance) {

    var DR = dataManager.DR;
    var DSD = appStateManager.DSD;
    var D = appStateManager.D;
    var DOF = appStateManager.DOF;
    $scope.DSD = appStateManager.DSD;
    $scope.canvases = appStateManager.DSD.product.canvases;
    $scope.dashboard = appStateManager.DSD.product.dashboard;

    $scope.ok = function () {
        $uibModalInstance.close();
    };


    if (D.role === 0) {
        $scope.ReportTypes = ['User', 'Admin'];
    }
    else {
        $scope.ReportTypes = ['User'];
    }
    

    $scope.boolShow = function (bool) { if (bool) { return 'Show'; } return 'Hide'; };
    $scope.pushReportCopy = function () {

        if (DSD.product.canvases[$scope.dashboard.index.canvas].fromDB === true) {
            DSD.product.canvases[$scope.dashboard.index.canvas].GUID = DOF.generateGUID();
        }

        DR.reports(DSD.product.canvases[$scope.dashboard.index.canvas]).then(function (resp)
        {

            //toastr.success('Report Created');
            $scope.ok();
            DSD.product.canvases[$scope.dashboard.index.canvas].overwrite = true;
            DSD.product.canvases[$scope.dashboard.index.canvas].fromDB = true;
            
        }).catch(function (e) { console.log(e); });
       
    };

    $scope.pushUpdatedReport = function () {
        DR.updateReport(DSD.product.canvases[$scope.dashboard.index.canvas]).then(function (resp) {
            $scope.ok();
        }).catch(function (e) { console.log(e); });
    }

}]);