﻿metricDashboard.controller('MetricDashboardCanvas', ['$scope', 'appStateManager', 'componentModifier', '$rootScope', 'dataManager', function ($scope, appStateManager, componentModifier, $rootScope, dataManager) {

    
    $scope.component = componentModifier;
    $scope.canvases = appStateManager.DSD.product.canvases;
    $scope.dashboard = appStateManager.DSD.product.dashboard;
    $scope.reports = appStateManager.DSD.product.reports;
    var product = appStateManager.DSD.product;
    $scope.index = product.dashboard.index;
     
    
    $scope.tabSelected = function (index) {
        $scope.dashboard.index.canvas = index;
    };

    $scope.backgroundPreview = false;

    $scope.gridsterOpts = {
        columns: 36,
        margins: [10,10],
        minRows: 3,
        resizable: {
            enabled: true,
            handles: ['n', 'e', 's', 'w', 'se', 'sw', 'nw']
        }
    }

    $scope.gridsterReportOpts = {
        columns: 36,
        margins: [10,10],
        minRows: 3,
        resizable: {
            enabled: false
        },
        draggable: {
            enabled: false
        }
    }

    $scope.addElement = function (index) {
        var element = {};
        element.name = 'New ' + componentModifier.elementTypes[index];
        element.type = componentModifier.elementTypes[index];
        componentModifier.addElement(element, $scope.index);
    };

    $scope.updateData = function(){
        console.log("data should update");
    };

}]);