﻿metricDashboard.controller('ReturnColumnController', ['$scope', 'appStateManager', '$uibModalInstance', function ($scope, appStateManager, $uibModalInstance) {

    var OT = appStateManager.OT;
    $scope.DSD = appStateManager.DSD;
    $scope.canvases = appStateManager.DSD.product.canvases;
    $scope.dashboard = appStateManager.DSD.product.dashboard;

    $scope.ok = function () {
        $uibModalInstance.close();
    };

    $scope.availableColumnIndex = -1;
    $scope.availableColumnSelected = function (index) {
        $scope.availableColumnIndex = index;
    };
    $scope.currentColumnIndex = -1;
    $scope.currentColumnSelected = function (index) {
        $scope.currentColumnIndex = index;
    };
    $scope.addColumnToFilter = function () {
        var columnProperty = angular.copy(OT.columnProperty);
        columnProperty.column = $scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group].data.tableColumns[$scope.availableColumnIndex].COLUMN_NAME;
        $scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group].data.columnProperties.push(columnProperty);
    };
    $scope.removeColumnFromFilter = function () {
        $scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group].data.columnProperties.splice($scope.currentColumnIndex, 1);
    }

}]);