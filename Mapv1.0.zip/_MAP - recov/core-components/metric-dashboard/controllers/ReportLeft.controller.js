﻿metricDashboard.controller('MetricDashboardReportLeft', ['$scope', 'appStateManager', 'dataManager', '$timeout', function ($scope, appStateManager, dataManager, $timeout) {

    var DR = dataManager.DR;
    var DSD = appStateManager.DSD;
    $scope.index = appStateManager.DSD.product.dashboard.index;
    $scope.reports = appStateManager.DSD.product.reports;
    $scope.dashboard = appStateManager.DSD.product.dashboard;


    DR.getReports('Admin').get().$promise.then(function (resp) {
        DSD.product.reports.length = 0;

        resp.model.forEach(function (item, index) {
            DSD.product.reports.push(JSON.parse(item.JSON_Value));
        })
    });

    $scope.groupSelected = function (index) {
        $scope.index.group = index;
    };

    $scope.showGroups = function () {
        var report = $scope.reports[$scope.index.report]
        if (report && report.dataGroups && report.dataGroups.length > 1) {
            return true;
        }
        return false;
    }

    $scope.filterClick = function () {

        $timeout(function () {
            var group = $scope.reports[$scope.index.report].dataGroups[$scope.index.group];

            group.data.query.filterColumn.length = 0;
            group.data.query.filterValue.length = 0;

            var filterLength = group.filters.length;
            for (var i = 0; i < filterLength; i++) {

                var filterColumn = Object.keys(group.filters[i].values[0])[0];

                var filterValues = group.filters[i].selectedValues.map(function (obj) {
                    return obj[filterColumn];
                });

                if (filterValues.length > 0) {
                    group.data.query.filterColumn.push(filterColumn);
                    group.data.query.filterValue.push(filterValues.join(","));
                }

            }

            DR.queryData(group.data.query).get().$promise.then(function (resp) {
                DR.updateArray(resp.model, group.data.result, group);
            });

        }, 1);
    };

    $scope.toggleClearSelect = function (index) {

        var filter = $scope.reports[$scope.index.report].dataGroups[$scope.index.group].filters[index];

        filter.selectToggle = filter.selectToggle || 0;
        if (filter.selectToggle === 0) {

            filter.values.forEach(function (entry) {
                filter.selectedValues.push(entry);
            });
            filter.selectToggle++;
        }
        else if (filter.selectToggle === 1) {

            filter.selectedValues.length = 0;
            filter.selectToggle--;
        }
        $scope.filterClick();

    };

}]);