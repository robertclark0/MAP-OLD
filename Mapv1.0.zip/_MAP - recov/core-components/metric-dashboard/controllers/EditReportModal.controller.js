﻿metricDashboard.controller('EditReportModal', ['$scope', 'appStateManager', 'dataManager', '$uibModalInstance', function ($scope, appStateManager, dataManager, $uibModalInstance) {

    var DR = dataManager.DR;
    var DSD = appStateManager.DSD;
    var D = appStateManager.D;
    var DOF = appStateManager.DOF;
    $scope.DSD = appStateManager.DSD;
    $scope.D = appStateManager.D;
    $scope.canvases = appStateManager.DSD.product.canvases;
    $scope.dashboard = appStateManager.DSD.product.dashboard;
    $scope.reports = appStateManager.DSD.product.reports;
    $scope.userReports = appStateManager.DSD.product.userReports;
    $scope.confirm = false;
    $scope.confirmUser = false;

    DR.getReports('Admin').get().$promise.then(function (resp) {
        DSD.product.reports.length = 0;

        resp.model.forEach(function (item, index) {
            DSD.product.reports.push(JSON.parse(item.JSON_Value));
        })
    }).catch(function (e) { console.log(e); });

    DR.getReports('User').get().$promise.then(function (resp) {
        DSD.product.userReports.length = 0;

        resp.model.forEach(function (item, index) {
            DSD.product.userReports.push(JSON.parse(item.JSON_Value));
        })
    }).catch(function (e) { console.log(e); });

    $scope.pushReportEdit = function () {
        
        $scope.canvases.push($scope.reports[$scope.dashboard.index.report]);

        var newCanvas = $scope.canvases[$scope.canvases.length - 1];
        newCanvas.overwrite = true;
        if (newCanvas.roleType === 'Admin' && D.role !== 0) {
            newCanvas.roleType = 'User';
            newCanvas.overwrite = false;
            newCanvas.fromDB = true;
        }


        $scope.ok();
    };
    $scope.pushUserReportEdit = function () {

        $scope.canvases.push($scope.userReports[$scope.dashboard.index.userReport]);

        var newCanvas = $scope.canvases[$scope.canvases.length - 1];
        newCanvas.overwrite = true;
        if (newCanvas.roleType === 'Admin' && D.role !== 0) {
            newCanvas.roleType = 'User';
            newCanvas.overwrite = false;
            newCanvas.fromDB = true;
        }

        $scope.ok();
    };

    $scope.deleteReport = function () {
        var GUID = DSD.product.reports[$scope.dashboard.index.report].GUID;
        DR.deleteReport(GUID).get().$promise.then(function () {
            $scope.ok();
            $scope.confirm = false;
        }).catch(function (e) {
            console.log(e);
            $scope.ok();
            $scope.confirm = false;
        });
    }
    $scope.deleteUserReport = function () {
        var GUID = DSD.product.userReports[$scope.dashboard.index.userReport].GUID;
        DR.deleteReport(GUID).get().$promise.then(function () {
            $scope.ok();
            $scope.confirm = false;
        }).catch(function (e) {
            console.log(e);
            $scope.ok();
            $scope.confirm = false;
        });
    }

    $scope.ok = function () {
        $uibModalInstance.close();
    };




}]);