﻿metricDashboard.controller('MetricDashboardRight', ['$scope', 'appStateManager','dataManager', '$uibModal', function ($scope, appStateManager,dataManager, $uibModal) {

    var DR = dataManager.DR;
    $scope.DSD = appStateManager.DSD;
    $scope.canvases = appStateManager.DSD.product.canvases;
    $scope.dashboard = appStateManager.DSD.product.dashboard;

    $scope.showAdvanced = function () {
        $scope.advanced = !$scope.advanced;
        console.log($scope.advanced);
    };
    $scope.advanced = false;

    var currentElement = function () {
        return $scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group].elements[$scope.dashboard.index.element];
    };

    $scope.boolGrouped = function (bool) { if (bool) { return 'Grouped'; } return 'Not Grouped'; };


    $scope.openReturnModal = function (size) {

        var modalInstance = $uibModal.open({
            animation: true,
            templateUrl: 'core-components/metric-dashboard/templates/return-column-modal.html',
            controller: 'ReturnColumnController',
            size: size
        });
    }

    $scope.propertyClick = function () {

        var groupData = $scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group].data;
        var group = $scope.canvases[$scope.dashboard.index.canvas].dataGroups[$scope.dashboard.index.group];
        
        groupData.query.column.length = 0;
        groupData.query.partition.length = 0;
        groupData.query.aggTypes.length = 0;
        groupData.query.group.length = 0;

        var length = groupData.columnProperties.length;

        for (var i = 0; i < length; i++)
        {
            groupData.query.column.push(groupData.columnProperties[i].column);
            groupData.query.aggTypes.push(groupData.columnProperties[i].aggregate);
            if (groupData.columnProperties[i].partition === true) {
                groupData.query.partition.push(groupData.columnProperties[i].column);
            }
            if (groupData.columnProperties[i].grouped === true) {
                groupData.query.group.push(groupData.columnProperties[i].column);
            }

        }

        DR.queryData(groupData.query).get().$promise.then(function (resp) {
            DR.updateArray(resp.model, groupData.result, group);
        }).catch(function () { groupData.result.length = 0; });
    }


    $scope.sendPost = function () {
        DR.reports();
    };
    
}]);