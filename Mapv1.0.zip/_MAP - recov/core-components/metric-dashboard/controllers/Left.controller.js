metricDashboard.controller('MetricDashboardLeft', ['$scope', 'appStateManager', 'dataManager', '$timeout', function ($scope, appStateManager, dataManager, $timeout) {

    var product = appStateManager.DSD.product;
    var DR = dataManager.DR;
    var DO = dataManager.DO;
    var toggle = 0;

    $scope.index = product.dashboard.index;
    $scope.dataGroups = product.canvases[$scope.index.canvas].dataGroups;

    $scope.canvases = appStateManager.DSD.product.canvases;
    $scope.dashboard = appStateManager.DSD.product.dashboard;

    $scope.groupSelected = function (index) {

        $scope.index.group = index;
    };

    $scope.filterClick = function () {

        $timeout(function () {

            var group = $scope.canvases[$scope.index.canvas].dataGroups[$scope.index.group];

            group.data.query.filterColumn.length = 0;
            group.data.query.filterValue.length = 0;

            var filterLength = group.filters.length;
            for (var i = 0; i < filterLength; i++) {

                var filterColumn = Object.keys(group.filters[i].values[0])[0];

                var filterValues = group.filters[i].selectedValues.map(function (obj) {
                    return obj[filterColumn];
                });

                if (filterValues.length > 0) {
                    group.data.query.filterColumn.push(filterColumn);
                    group.data.query.filterValue.push(filterValues.join(","));
                }

            }

            DR.queryData(group.data.query).get().$promise.then(function (resp) {
                console.log(resp.model);
                DR.updateArray(resp.model, group.data.result, group);
            }).catch(function () { group.data.result.length = 0; });

        }, 1);
    };

    $scope.toggleClearSelect = function (index) {

        var filter = $scope.canvases[$scope.index.canvas].dataGroups[$scope.index.group].filters[index];

        filter.selectToggle = filter.selectToggle || 0;
        if (filter.selectToggle === 0) {

            filter.values.forEach(function (entry) {
                filter.selectedValues.push(entry);
            });
            filter.selectToggle++;
        }
        else if (filter.selectToggle === 1) {

            filter.selectedValues.length = 0;
            filter.selectToggle--;
        }
        $scope.filterClick();

    };

}]);