﻿metricDashboard.controller('ComponentModal', ['$scope', '$uibModalInstance', 'appStateManager', 'componentModifier', 'dataManager', function ($scope, $uibModalInstance, appStateManager, componentModifier, dataManager) {


    $scope.component = componentModifier;
    var OT = appStateManager.OT;
    var product = appStateManager.DSD.product;
    $scope.index = product.dashboard.index;
    $scope.canvases = product.canvases;
    $scope.DO = dataManager.DO;
    var DR = dataManager.DR;


    //    CANVASES
    //
    $scope.newCanvasName = { name: '' };
    $scope.filterCanvasSelection = function () {
        if ($scope.canvases[$scope.index.canvas]) {
            return "Canvas: " + $scope.canvases[$scope.index.canvas].name;
        }
        return "Select Canvas";
    }
    $scope.canvasSelected = function (index) {
        $scope.index.canvas = index;
    };


    //    DATA GROUPS
    //
    $scope.newGroupName = { name: '' };
    $scope.filterDataGroupSelection = function () {
        if ($scope.canvases[$scope.index.canvas] && $scope.canvases[$scope.index.canvas].dataGroups[$scope.index.group]) {
            return "Data Group: " + $scope.canvases[$scope.index.canvas].dataGroups[$scope.index.group].name;
        }
        return "Select Data Group";
    }
    $scope.groupSelected = function (index) {
        $scope.index.group = index;
    };


    //    RETURN VALUES
    //
    $scope.availableValueIndex = -1;
    $scope.availableValueSelected = function (index) {
        $scope.availableValueIndex = index;
    };
    $scope.currentValueIndex = -1;
    $scope.currentValueSelected = function (index) {
        $scope.currentValueIndex = index;
    };
    $scope.addValueToReturn = function () {
        var columnProperty = angular.copy(OT.columnProperty);
        columnProperty.column = $scope.canvases[$scope.index.canvas].dataGroups[$scope.index.group].data.tableColumns[$scope.availableValueIndex].COLUMN_NAME;
        $scope.canvases[$scope.index.canvas].dataGroups[$scope.index.group].data.columnProperties.push(columnProperty);
    };
    $scope.removeValueFromReturn = function () {
        $scope.canvases[$scope.index.canvas].dataGroups[$scope.index.group].data.columnProperties.splice($scope.currentValueIndex, 1);
    }


    //    FILTERS
    //
    $scope.newFilterName = { name: '' };
    $scope.filterSelected = function (index) {
        $scope.index.filter = index;
    };

    $scope.availableColumnIndex = -1;
    $scope.availableColumnSelected = function (index) {
        $scope.availableColumnIndex = index;
        //new
        $scope.newFilterName.name = $scope.canvases[$scope.index.canvas].dataGroups[$scope.index.group].data.tableColumns[index].COLUMN_NAME
    };
    $scope.currentColumnIndex = -1;
    $scope.currentColumnSelected = function (index) {
        $scope.currentColumnIndex = index;
    };

    $scope.tempNewFilterColumns = [];
    $scope.addColumnToFilter = function () {
        $scope.tempNewFilterColumns.push($scope.canvases[$scope.index.canvas].dataGroups[$scope.index.group].data.tableColumns[$scope.availableColumnIndex]);
        $scope.newFilterName.name = $scope.canvases[$scope.index.canvas].dataGroups[$scope.index.group].data.tableColumns[$scope.availableColumnIndex].COLUMN_NAME
    };
    $scope.removeColumnFromFilter = function () {
        $scope.tempNewFilterColumns.splice($scope.currentColumnIndex, 1);      
    }
    $scope.addFilter = function () {
        $scope.component.addFilter($scope.newFilterName, $scope.index, $scope.canvases[$scope.index.canvas].dataGroups[$scope.index.group].data.tableColumns[$scope.availableColumnIndex]);
        $scope.tempNewFilterColumns.length = 0;
    };


    //    ELEMENTS
    //
    $scope.element = {
        name: '',
        width: 3,
        height: 3,
        type: 'Select Element Type'
    };
    $scope.elementIndexValue = -1;

    $scope.elementTypeSelected = function (type) {
        $scope.element.type = type;
    };
    $scope.elementSelected = function (index) {
        $scope.index.element = index;
    };


    //    MODAL CONTROLLS
    //
    $scope.ok = function () {
        $uibModalInstance.close();
    };

    $scope.cancel = function () {
        $uibModalInstance.dismiss('cancel');
    };



}]);