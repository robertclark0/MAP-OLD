﻿metricDashboard.factory('componentModifier', function (appStateManager, $uibModal, dataManager) {

    var DSD = appStateManager.DSD;
    var OT = appStateManager.OT;
    var DOF = appStateManager.DOF;
    var DR = dataManager.DR;
    var DO = dataManager.DO;
    var modifier = {};

    modifier.elementTypes = ['title-block', 'text-block', 'chart-element', 'hc-chart', 'data-text','spacer']; // 'donut-chart', 'gauge-chart'


    //    CANVASES
    //
    modifier.addCanvas = function () {
        var newCanvas = angular.copy(OT.Canvas);
        newCanvas.GUID = DOF.generateGUID();
        DSD.product.canvases.push(newCanvas);
    };
    modifier.addCanvasByName = function (canvasObject) {
        var newCanvas = angular.copy(OT.Canvas);
        newCanvas.name = canvasObject.name;
        newCanvas.GUID = DOF.generateGUID();
        DSD.product.canvases.push(newCanvas);
        canvasObject.name = null;
    };
    modifier.deleteCanvas = function (indexObject) {
        DSD.product.canvases.splice(indexObject.canvas, 1);
    };


    //    DATA GROUPS
    //
    modifier.addGroup = function (groupObject, indexObject) {

        var newGroup = angular.copy(OT.Group);
        newGroup.name = groupObject.name;
        DSD.product.canvases[indexObject.canvas].dataGroups.push(newGroup);
        indexObject.group = DSD.product.canvases[indexObject.canvas].dataGroups.length - 1;
        groupObject.name = null;

        DR.tableColumnData.get().$promise.then(function (resp) {

            //DR.updateData(DO.product.dataQueries, resp, indexObject.canvas, DSD.product.canvases[indexObject.canvas].dataGroups.length - 1);
            DR.updateArray(resp.model, DSD.product.canvases[indexObject.canvas].dataGroups[indexObject.group].data.tableColumns, DSD.product.canvases[indexObject.canvas].dataGroups[indexObject.group]);
        });
    };
    modifier.deleteGroup = function (indexObject) {

        DSD.product.canvases[indexObject.canvas].dataGroups.splice(indexObject.group, 1);
    };


    //    FILTERS
    //
    modifier.addFilter = function (filterObject, indexObject, columnObject) {

        var newFilter = angular.copy(OT.Filter);
        newFilter.name = filterObject.name;
        DSD.product.canvases[indexObject.canvas].dataGroups[indexObject.group].filters.push(newFilter);
        filterObject.name = null;

        DR.testDistinctColumnData(columnObject.COLUMN_NAME, columnObject.DATA_TYPE).get().$promise.then(function (resp) {
            DSD.product.canvases[indexObject.canvas].dataGroups[indexObject.group].filters[DSD.product.canvases[indexObject.canvas].dataGroups[indexObject.group].filters.length - 1].values = resp.model;
            //console.log(resp.model);
            return true;
        });
    };
    modifier.deleteFilter = function (indexObject) {

        DSD.product.canvases[indexObject.canvas].dataGroups[indexObject.group].filters.splice(indexObject.filter, 1);
    };


    //    ELEMENTS
    //
    modifier.addElement = function (elementObject, indexObject) {

        var newElement = angular.copy(OT.Element);
        newElement.name = elementObject.name;
        newElement.type = elementObject.type;
        newElement.width = parseInt(elementObject.width) || 8;
        newElement.height = parseInt(elementObject.height) || 5;

        DSD.product.canvases[indexObject.canvas].dataGroups[indexObject.group].elements.push(newElement);
        elementObject.name = null;
    };
    modifier.deleteElement = function (indexObject) {

        DSD.product.canvases[indexObject.canvas].dataGroups[indexObject.group].elements.splice(indexObject.element, 1);
    };


    //    MODAL
    //
    modifier.openModal = function (size) {

        var modalInstance = $uibModal.open({
            animation: true,
            templateUrl: 'core-components/metric-dashboard/templates/component-modal.html',
            controller: 'ComponentModal',
            size: size
        });
    };



    return modifier;

});