﻿mapApp.directive('headerNotification', function () {
	    return {
	        templateUrl: 'core-components/metric-dashboard/directives/header-menu.html',
	        restrict: 'E',
	        replace: true,
	    }
});