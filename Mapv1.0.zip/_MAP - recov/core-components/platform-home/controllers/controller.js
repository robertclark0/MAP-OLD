﻿platformHome.controller('PlatformHome', ['$scope', '$state', 'tempService', 'appStateManager', 'dataManager', function ($scope, $state, tempService, appStateManager, dataManager) {

    $scope.products = tempService.products;
    $scope.titles = tempService.titles;
    $scope.future = tempService.future;

    //var data = appStateManager;
    var D = appStateManager.D;
    var DOF = appStateManager.DOF;
    var DR = dataManager.DR;

    $scope.passProduct = function (product) {

        DR.userInfo().get().$promise.then(function (resp) {

            if (resp.RoleInfo && resp.RoleInfo[0].roleName) {
                if (resp.RoleInfo[0].roleName === 'Report Admin') {
                    D.role = 0;
                }
                else if (resp.RoleInfo[0].roleName === 'Report Builder') {
                    D.role = 1;
                }
            }

            DOF.setProductLine(product);

            if (D[product.dataName]) {
                if (D[product.dataName].dashboard.mode === 'Analysis') {
                    goRoute('metricDashboard');
                }
                else {
                    goRoute('metricDashboardReporting');
                }
            }
            else {
                console.log("error loading service line");
            }

        }).catch(function (error) {
            console.log("Error collecting user data");
            console.log(error);
            DOF.setProductLine(product);

            if (D[product.dataName]) {
                if (D[product.dataName].dashboard.mode === 'Analysis') {
                    goRoute('metricDashboard');
                }
                else {
                    goRoute('metricDashboardReporting');
                }
            }
            else {
                console.log("error loading service line");
            }
        });

    };

    var goRoute = function (routeName) {
        $state.go(routeName);
    };

}]);