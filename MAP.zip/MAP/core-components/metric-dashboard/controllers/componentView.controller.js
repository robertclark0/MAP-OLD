﻿metricDashboard.controller('ComponentView', ['$scope', 'appManager', function ($scope, appManager) {

    //    Controller and Scope variables
    //var SF = appManager.state.SF;
    //var SO = appManager.state.SO;
    //var DSO = appManager.state.DSO;

    

}]);