﻿metricDashboard.controller('MetricDashboard', ['$scope', 'appStateManager', function ($scope, appStateManager, $rootScope) {

    var SF = appStateManager.SF;
    var SO = appStateManager.SO;
    var DSO = appStateManager.DSO;
    
    DSO = SO[SO.productLine.current];
    $scope.name = DSO.name;



}]);