﻿metricDashboard.controller('MetricDashboard', ['$scope', 'appManager', '$mdDialog', function ($scope, appManager, $mdDialog) {

    //    Controller and Scope variables
    var SF = appManager.state.SF;
    var SO = appManager.state.SO;
    //appManager.state.DSO = SO[SO.productLine.current];
    var DSO = appManager.state.DSO;

    console.log(DSO);
    $scope.name = DSO.name;
    $scope.propertyPanel = DSO.dashboard.propertyPanel;
    //



    //Dashboard Components Diaglog
    $scope.showTabDialog = function (ev) {
        $mdDialog.show({
            controller: 'DashboardComponents',
            templateUrl: 'core-components/metric-dashboard/templates/dashboardComponents.html',
            parent: angular.element(document.body),
            targetEvent: ev,
            clickOutsideToClose: true,
            hasBackdrop: false
        })
            .then(function (answer) {
                $scope.status = 'You said the information was "' + answer + '".';
            }, function () {
                $scope.status = 'You cancelled the dialog.';
            });
    };

}]);