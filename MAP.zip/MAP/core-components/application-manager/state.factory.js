﻿applicationManager.factory('appStateManager', ['$rootScope', '$sessionStorage', function ($rootScope, $sessionStorage) {

    //    STATE OBJECT CLASSES
    //
    var stateClasses = {};

    stateClasses.StateObject = function () {
        this.productLine = {
            current: "none", //product line name
            role: 0
        };
    };
    stateClasses.ProductLine = function (name) {
        this.name = name;
        this.dashboard = {
            mode: 'Reporting', //Reporting, Analysis
            modeView: 'Canvas', //Canvas, Grid
            index: {
                report: 0,
                userReport: 0,
                canvas: 0,
                group: 0,
                element: 0,
                filter: 0,
            }
        };
        this.reports = [];
        this.canvases = [new stateClasses.Canvas];
    };
    stateClasses.Canvas = function (GUID) {
        this.name = 'Canvas';
        this.GUID = GUID;
        this.roleType = 'User'; //User, Admin
        this.dataGroups = [];
        
    };
    stateClasses.Group = function (GUID) {
        this.name = '';
        this.GUID = GUID;
        this.dataSource = '';
        this.filters = [];
        this.elements = [];
        this.data = {
            results: [],
            tableColumns: [],
            columnProperties: [],
            query: {}, //ToChange - need way to include query for stored proc
            calc: {} //ToChange - expand calculation cababilities
        }
    };
    stateClasses.Filter = function (GUID) {
        this.name = '';
        this.GUID = GUID;
        this.visibleInReport = true;
        this.selectedValue = [];
    };
    stateClasses.Element = function () {
        this.name = '';
        this.type = '';
        this.width = 3;
        this.height = 3;
        this.posX = 0;
        this.posY = 0;
    };
    stateClasses.ColumnProperty = function () {
        this.column = '';
        this.aggregate = 'none';
        this.partition = false;
        this.grouped = false;
    };


    //    STATE DATA FUNCTIONS
    //
    var stateFunctions = {};

    stateFunctions.generateGUID = function () {
        var d = new Date().getTime();
        if (window.performance && typeof window.performance.now === "function") {
            d += performance.now(); //use high-precision timer if available
        }
        var GUID = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = (d + Math.random() * 16) % 16 | 0;
            d = Math.floor(d / 16);
            return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
        });
        return GUID;
    };
    stateFunctions.newStateObject = function (type) {
        switch (type) {
            case 'Canvas':
                return new stateClasses.Canvas(stateFunctions.generateGUID());
            case 'Group':
                return new stateClasses.Group(stateFunctions.generateGUID());
            case 'Filter':
                return new stateClasses.Filter(stateFunctions.generateGUID());
            case 'Element':
                return new stateClasses.Element;
            case 'ColumnProperty':
                return new stateClasses.ColumnProperty;
        }
    };
    stateFunctions.Current = function (indexedObjectName) {
        switch (indexedObjectName) {
            case 'Canvas':
                return 'Canvas';
        }
    };
    stateFunctions.setProduct = function (product) {
        session.StateObject.productLine.current = product.Code;
        session.StateObject[product.Code] = (typeof session.StateObject[product.Code] === 'undefined') ? new stateClasses.ProductLine(product.Name) : session.StateObject[product.Code];
    };


    //    DATA STUCTURES
    //
    var stateScope = $rootScope.$new(true);

    var session = $sessionStorage;
    session.StateObject = (typeof session.StateObject === 'undefined') ? new stateClasses.StateObject : session.StateObject;
    session.DynamicStateObject = (typeof session.DynamicStateObject === 'undefined') ? {} : session.DynamicStateObject;

    stateScope.DSO = session.DynamicStateObject;
    stateScope.SO = session.StateObject;
    stateScope.SF = stateFunctions;

    return stateScope;

}]);