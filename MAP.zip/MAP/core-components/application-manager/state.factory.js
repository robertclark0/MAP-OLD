﻿applicationManager.factory('appStateManager', ['$rootScope', '$sessionStorage', '$state', function ($rootScope, $sessionStorage, $state) {

    //    STATE OBJECT CLASSES
    //
    var stateClasses = {};

    stateClasses.StateObject = function () {
        this.productLine = {
            current: "none", //product line name
            role: 0
        };
    };
    stateClasses.ProductLine = function (name) {
        this.name = name;
        this.dashboard = {
            mode: 'reporting', //reporting, analysis
            modeView: 'canvas', //canvas, data
            index: {
                report: 0,
                userReport: 0,
                canvas: 0,
                group: 0,
                element: 0,
                filter: 0,
            },
            propertyPanel: [
                {
                    side: 'right', // left, right
                    lock: false,
                    templateUrl: 'core-components/metric-dashboard/templates/filter.sideNav.html'
                },
                {
                    side: 'left',
                    lock: false,
                    templateUrl: 'core-components/metric-dashboard/templates/dataValue.sideNav.html'
                }
            ]
        };
        this.reports = [];
        this.canvases = [new stateClasses.Canvas];
    };
    stateClasses.Canvas = function (GUID) {
        this.name = 'Canvas';
        this.GUID = GUID;
        this.roleType = 'user'; //user, admin
        this.dataGroups = [];
        
    };
    stateClasses.Group = function (GUID) {
        this.name = '';
        this.GUID = GUID;
        this.dataSource = '';
        this.filters = [];
        this.elements = [];
        this.data = {
            results: [],
            tableColumns: [],
            columnProperties: [],
            query: {}, //ToChange - need way to include query for stored proc
            calc: {} //ToChange - expand calculation cababilities
        }
    };
    stateClasses.Filter = function (GUID) {
        this.name = '';
        this.GUID = GUID;
        this.visibleInReport = true;
        this.selectedValue = [];
    };
    stateClasses.Element = function () {
        this.name = '';
        this.type = '';
        this.width = 3;
        this.height = 3;
        this.posX = 0;
        this.posY = 0;
    };
    stateClasses.ColumnProperty = function () {
        this.column = '';
        this.aggregate = 'none';
        this.partition = false;
        this.grouped = false;
    };


    //    STATE DATA FUNCTIONS
    //
    var stateFunctions = {};

    stateFunctions.generateGUID = function () {
        var d = new Date().getTime();
        if (window.performance && typeof window.performance.now === "function") {
            d += performance.now(); //use high-precision timer if available
        }
        var GUID = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = (d + Math.random() * 16) % 16 | 0;
            d = Math.floor(d / 16);
            return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
        });
        return GUID;
    };
    stateFunctions.newStateObject = function (type) {
        switch (type) {
            case 'canvas':
                return new stateClasses.Canvas(stateFunctions.generateGUID());
            case 'group':
                return new stateClasses.Group(stateFunctions.generateGUID());
            case 'filter':
                return new stateClasses.Filter(stateFunctions.generateGUID());
            case 'element':
                return new stateClasses.Element;
            case 'columnProperty':
                return new stateClasses.ColumnProperty;
        }
    };
    stateFunctions.Current = function (indexedObjectName) {
        switch (indexedObjectName) {
            case 'canvas':
                return 'canvas';
        }
    };
    stateFunctions.setProduct = function (product, state) {
        session.StateObject.productLine.current = product.Code;
        session.StateObject[product.Code] = (typeof session.StateObject[product.Code] === 'undefined') ? new stateClasses.ProductLine(product.Name) : session.StateObject[product.Code];

        session.DynamicStateObject = session.StateObject[product.Code];
        stateScope.DSO = session.DynamicStateObject;

        if (state)
        {
            $state.go(state);
        }
    };


    //    DATA STUCTURES
    //
    var stateScope = $rootScope.$new(true);

    var session = $sessionStorage;
    session.StateObject = (typeof session.StateObject === 'undefined') ? new stateClasses.StateObject : session.StateObject;
    session.DynamicStateObject = (typeof session.DynamicStateObject === 'undefined') ? {} : session.DynamicStateObject;

    stateScope.DSO = session.DynamicStateObject;
    stateScope.SO = session.StateObject;
    stateScope.SF = stateFunctions;

    return stateScope;

}]);