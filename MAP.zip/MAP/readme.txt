Project Structure:

Deloy:

-assets
-core-components /less js files
-shared-components /less js files
-index.html