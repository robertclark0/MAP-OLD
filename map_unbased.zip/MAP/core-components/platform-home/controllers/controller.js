﻿platformHome.controller('PlatformHome', ['$scope', 'appStateManager', 'temp', '$state', function ($scope, appStateManager, temp, $state) {

    var SF = appStateManager.SF;
    var SO = appStateManager.SO;
    var DSO = appStateManager.DSO;

    SO.productLines = temp.data;

    $scope.products = SO.productLines;

    $scope.passProduct = function (product) {

        SF.setProduct(product);
        $state.go('metricDashboard');
        

    };

}]);