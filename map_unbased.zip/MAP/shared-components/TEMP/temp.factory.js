﻿mapApp.factory('temp', [function () {

    var fac = {

        data: [
            { "ProductLineID": "11", "Name": "Access To Care", "Description": "NULL", "Active": "0", "ShortName": "ATC", "Module": "Coming Soon!", "Icon": "caduceus1", "IconClass": "color4" },
            { "ProductLineID": "8", "Name": "Behavioral Health", "Description": "NULL", "Active": "0", "ShortName": "BH360", "Module": "Coming Soon!", "Icon": "bh360", "IconClass": "colorMed" },
            { "ProductLineID": "2", "Name": "Beneficiary Health", "Description": "NULL", "Active": "0", "ShortName": "BH", "Module": "Coming Soon!", "Icon": "family21", "IconClass": "color5" },
            { "ProductLineID": "7", "Name": "Coding", "Description": "NULL", "Active": "0", "ShortName": "CODING", "Module": "Coming Soon!", "Icon": "numbered10", "IconClass": "color1" },
            { "ProductLineID": "5", "Name": "Data Processing", "Description": "NULL", "Active": "0", "ShortName": "DP", "Module": "Coming Soon!", "Icon": "monitor7", "IconClass": "color5" },
            { "ProductLineID": "6", "Name": "Data Quality", "Description": "NULL", "Active": "0", "ShortName": "DQ", "Module": "Coming Soon!", "Icon": "positive3", "IconClass": "color2" },
            { "ProductLineID": "3", "Name": "Public Health", "Description": "Public health information for installations", "Active": "0", "ShortName": "PH360", "Module": "Coming Soon!", "Icon": "ph360", "IconClass": "colorMed" },
            { "ProductLineID": "9", "Name": "TeleHealth", "Description": "NULL", "Active": "1", "ShortName": "TELE360", "Module": "Metric Dashboard", "Icon": "th", "IconClass": "colorMed" },
            { "ProductLineID": "10", "Name": "Utilization", "Description": "NULL", "Active": "0", "ShortName": "UTL", "Module": "Coming Soon!", "Icon": "circle54", "IconClass": "color3" }
        ]
    };

    return fac;
}]);