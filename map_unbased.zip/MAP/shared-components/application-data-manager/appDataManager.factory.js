﻿mapApp.factory('appDataManager', ['$rootScope', function ($rootScope) {

    //    DATA STUCTURES
    //
    var dataScope = $rootScope.$new(true);

    return dataScope;

}]);