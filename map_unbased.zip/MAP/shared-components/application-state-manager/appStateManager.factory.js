﻿mapApp.factory('appStateManager', ['$rootScope', '$sessionStorage', function ($rootScope, $sessionStorage) {

    //    STATE OBJECT CLASSES
    //
    var stateClasses = {};

    stateClasses.StateObject = function () {
        this.productLine = {
            current: "none", //product line name
            role: 0
        };
    };
    stateClasses.ProductLine = function (name) {
        this.name = name;
        this.dashboard = {
            mode: 'Reporting', //Reporting, Analysis
            modeView: 'Canvas', //Canvas, Grid
            index: {
                report: 0,
                userReport: 0,
                canvas: 0,
                group: 0,
                element: 0,
                filter: 0,
            }
        };
        this.reports = [];
        this.canvases = [new stateClasses.Canvas];
    };
    stateClasses.Canvas = function () {
        this.name = 'Canvas';
        this.roleType = 'User'; //User, Admin
        this.dataGroups = [];
    };
    stateClasses.Group = function () {
        this.name = '';
        this.dataSource = '';
        this.filters = [];
        this.elements = [];
        this.data = {
            results: [],
            tableColumns: [],
            columnProperties: [],
            query: {}, //ToChange - need way to include query for stored proc
            calc: {} //ToChange - expand calculation cababilities
        }
    };
    stateClasses.Filter = function () {
        this.name = '';
        this.visibleInReport = true;
        this.selectedValue = [];
    };
    stateClasses.Element = function () {
        this.name = '';
        this.type = '';
        this.width = 3;
        this.height = 3;
        this.posX = 0;
        this.posY = 0;
    };
    stateClasses.ColumnProperty = function () {
        this.column = '';
        this.aggregate = 'none';
        this.partition = false;
        this.grouped = false;
    };


    //    STATE DATA FUNCTIONS
    //
    var stateFunctions = {};

    stateFunctions.dataObject = function (type) {
        switch (type) {
            case 'Canvas':
                return new stateClasses.Canvas;
            case 'Group':
                return new stateClasses.Group;
            case 'Filter':
                return new stateClasses.Filter;
            case 'Element':
                return new stateClasses.Element;
            case 'ColumnProperty':
                return new stateClasses.ColumnProperty;
        }
    };
    stateFunctions.Current = function (indexedObjectName) {
        switch (indexedObjectName) {
            case 'Canvas':
                return 'Canvas';
        }
    };
    stateFunctions.setProduct = function (product) {

        session.StateObject.productLine.current = product.ShortName;
        session.StateObject[product.ShortName] = (typeof session.StateObject[product.ShortName] === 'undefined') ? new stateClasses.ProductLine(product.Name) : session.StateObject[product.ShortName];
        //session.DynamicStateObject = session.StateObject[product.ShortName]
    };


    //    DATA STUCTURES
    //
    var stateScope = $rootScope.$new(true);
    //var stateScope = {};

    var session = $sessionStorage;
    session.StateObject = (typeof session.StateObject === 'undefined') ? new stateClasses.StateObject : session.StateObject;
    session.DynamicStateObject = (typeof session.DynamicStateObject === 'undefined') ? {} : session.DynamicStateObject;

    stateScope.DSO = session.DynamicStateObject;
    stateScope.SO = session.StateObject;
    stateScope.SC = stateClasses;
    stateScope.SF = stateFunctions;

    return stateScope;

}]);