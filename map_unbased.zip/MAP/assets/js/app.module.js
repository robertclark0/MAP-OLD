﻿var mapApp = angular.module('mapApp', [
    'ngMaterial',
    'ngAnimate',
    'ngSanitize',
    'ui.router',
    'ngStorage',
    'platformHome',
    'metricDashboard',
    'reportViewer'
]);