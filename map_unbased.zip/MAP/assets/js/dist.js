var mapApp = angular.module('mapApp', [
    'ngMaterial',
    'ngAnimate',
    'ngSanitize',
    'ui.router',
    'ngStorage',
    'platformHome',
    'metricDashboard',
    'reportViewer'
]);
var metricDashboard = angular.module('metricDashboard', []);
var platformHome = angular.module('platformHome', []);
var reportViewer = angular.module('reportViewer', []);
mapApp.config(function ($stateProvider, $urlRouterProvider) {

    $urlRouterProvider.otherwise("/platform-home/product-lines");

    $stateProvider
        .state("platformHome", {
            url: "/platform-home",
            templateUrl: "core-components/platform-home/templates/view.html",
            controller: "PlatformHome"
        })
        .state("platformHome.productLines", {
            url: "/product-lines",
            templateUrl: "core-components/platform-home/templates/product-lines.html",
            controller: "PlatformHome"
        })
        .state("reportViewer", {
            url: "/report-viewer",
            templateUrl: "core-components/report-viewer/templates/view.html"
        })
        .state("metricDashboard", {
            url: "/metric-dashboard",
            templateUrl: "core-components/metric-dashboard/templates/view.html",
            controller: 'MetricDashboard'
        });
});
mapApp.config(function ($mdThemingProvider) {
    $mdThemingProvider.theme('default')
      .primaryPalette('green')
      .accentPalette('blue');
});
mapApp.factory('appDataManager', ['$rootScope', function ($rootScope) {

    //    DATA STUCTURES
    //
    var dataScope = $rootScope.$new(true);

    return dataScope;

}]);
mapApp.factory('appStateManager', ['$rootScope', '$sessionStorage', function ($rootScope, $sessionStorage) {

    //    STATE OBJECT CLASSES
    //
    var stateClasses = {};

    stateClasses.StateObject = function () {
        this.productLine = {
            current: "none", //product line name
            role: 0
        };
    };
    stateClasses.ProductLine = function (name) {
        this.name = name;
        this.dashboard = {
            mode: 'Reporting', //Reporting, Analysis
            modeView: 'Canvas', //Canvas, Grid
            index: {
                report: 0,
                userReport: 0,
                canvas: 0,
                group: 0,
                element: 0,
                filter: 0,
            }
        };
        this.reports = [];
        this.canvases = [new stateClasses.Canvas];
    };
    stateClasses.Canvas = function () {
        this.name = 'Canvas';
        this.roleType = 'User'; //User, Admin
        this.dataGroups = [];
    };
    stateClasses.Group = function () {
        this.name = '';
        this.dataSource = '';
        this.filters = [];
        this.elements = [];
        this.data = {
            results: [],
            tableColumns: [],
            columnProperties: [],
            query: {}, //ToChange - need way to include query for stored proc
            calc: {} //ToChange - expand calculation cababilities
        }
    };
    stateClasses.Filter = function () {
        this.name = '';
        this.visibleInReport = true;
        this.selectedValue = [];
    };
    stateClasses.Element = function () {
        this.name = '';
        this.type = '';
        this.width = 3;
        this.height = 3;
        this.posX = 0;
        this.posY = 0;
    };
    stateClasses.ColumnProperty = function () {
        this.column = '';
        this.aggregate = 'none';
        this.partition = false;
        this.grouped = false;
    };


    //    STATE DATA FUNCTIONS
    //
    var stateFunctions = {};

    stateFunctions.dataObject = function (type) {
        switch (type) {
            case 'Canvas':
                return new stateClasses.Canvas;
            case 'Group':
                return new stateClasses.Group;
            case 'Filter':
                return new stateClasses.Filter;
            case 'Element':
                return new stateClasses.Element;
            case 'ColumnProperty':
                return new stateClasses.ColumnProperty;
        }
    };
    stateFunctions.Current = function (indexedObjectName) {
        switch (indexedObjectName) {
            case 'Canvas':
                return 'Canvas';
        }
    };
    stateFunctions.setProduct = function (product) {

        session.StateObject.productLine.current = product.ShortName;
        session.StateObject[product.ShortName] = (typeof session.StateObject[product.ShortName] === 'undefined') ? new stateClasses.ProductLine(product.Name) : session.StateObject[product.ShortName];
        //session.DynamicStateObject = session.StateObject[product.ShortName]
    };


    //    DATA STUCTURES
    //
    var stateScope = $rootScope.$new(true);
    //var stateScope = {};

    var session = $sessionStorage;
    session.StateObject = (typeof session.StateObject === 'undefined') ? new stateClasses.StateObject : session.StateObject;
    session.DynamicStateObject = (typeof session.DynamicStateObject === 'undefined') ? {} : session.DynamicStateObject;

    stateScope.DSO = session.DynamicStateObject;
    stateScope.SO = session.StateObject;
    stateScope.SC = stateClasses;
    stateScope.SF = stateFunctions;

    return stateScope;

}]);
platformHome.controller('MetricDashboard', ['$scope', 'appStateManager', function ($scope, appStateManager, $rootScope) {

    var SF = appStateManager.SF;
    var SO = appStateManager.SO;
    var DSO = appStateManager.DSO;
    
    DSO = SO[SO.productLine.current];
    $scope.name = DSO.name;



}]);
platformHome.controller('PlatformHome', ['$scope', 'appStateManager', 'temp', '$state', function ($scope, appStateManager, temp, $state) {

    var SF = appStateManager.SF;
    var SO = appStateManager.SO;
    var DSO = appStateManager.DSO;

    SO.productLines = temp.data;

    $scope.products = SO.productLines;

    $scope.passProduct = function (product) {

        SF.setProduct(product);
        $state.go('metricDashboard');
        

    };

}]);
mapApp.factory('temp', [function () {

    var fac = {

        data: [
            { "ProductLineID": "11", "Name": "Access To Care", "Description": "NULL", "Active": "0", "ShortName": "ATC", "Module": "Coming Soon!", "Icon": "caduceus1", "IconClass": "color4" },
            { "ProductLineID": "8", "Name": "Behavioral Health", "Description": "NULL", "Active": "0", "ShortName": "BH360", "Module": "Coming Soon!", "Icon": "bh360", "IconClass": "colorMed" },
            { "ProductLineID": "2", "Name": "Beneficiary Health", "Description": "NULL", "Active": "0", "ShortName": "BH", "Module": "Coming Soon!", "Icon": "family21", "IconClass": "color5" },
            { "ProductLineID": "7", "Name": "Coding", "Description": "NULL", "Active": "0", "ShortName": "CODING", "Module": "Coming Soon!", "Icon": "numbered10", "IconClass": "color1" },
            { "ProductLineID": "5", "Name": "Data Processing", "Description": "NULL", "Active": "0", "ShortName": "DP", "Module": "Coming Soon!", "Icon": "monitor7", "IconClass": "color5" },
            { "ProductLineID": "6", "Name": "Data Quality", "Description": "NULL", "Active": "0", "ShortName": "DQ", "Module": "Coming Soon!", "Icon": "positive3", "IconClass": "color2" },
            { "ProductLineID": "3", "Name": "Public Health", "Description": "Public health information for installations", "Active": "0", "ShortName": "PH360", "Module": "Coming Soon!", "Icon": "ph360", "IconClass": "colorMed" },
            { "ProductLineID": "9", "Name": "TeleHealth", "Description": "NULL", "Active": "1", "ShortName": "TELE360", "Module": "Metric Dashboard", "Icon": "th", "IconClass": "colorMed" },
            { "ProductLineID": "10", "Name": "Utilization", "Description": "NULL", "Active": "0", "ShortName": "UTL", "Module": "Coming Soon!", "Icon": "circle54", "IconClass": "color3" }
        ]
    };

    return fac;
}]);