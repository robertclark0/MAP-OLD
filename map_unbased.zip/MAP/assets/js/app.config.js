﻿mapApp.config(function ($stateProvider, $urlRouterProvider) {

    $urlRouterProvider.otherwise("/platform-home/product-lines");

    $stateProvider
        .state("platformHome", {
            url: "/platform-home",
            templateUrl: "core-components/platform-home/templates/view.html",
            controller: "PlatformHome"
        })
        .state("platformHome.productLines", {
            url: "/product-lines",
            templateUrl: "core-components/platform-home/templates/product-lines.html",
            controller: "PlatformHome"
        })
        .state("reportViewer", {
            url: "/report-viewer",
            templateUrl: "core-components/report-viewer/templates/view.html"
        })
        .state("metricDashboard", {
            url: "/metric-dashboard",
            templateUrl: "core-components/metric-dashboard/templates/view.html",
            controller: 'MetricDashboard'
        });
});
mapApp.config(function ($mdThemingProvider) {
    $mdThemingProvider.theme('default')
      .primaryPalette('green')
      .accentPalette('blue');
});